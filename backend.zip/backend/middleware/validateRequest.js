/**
 * INSURE AI — Request validation middleware
 *
 * Validates and sanitises incoming requests before they reach route handlers.
 * Prevents prompt injection, empty payloads, and oversized inputs.
 */

"use strict";

const MAX_STRING_LENGTH = 2000;
const MAX_DESCRIPTION_LENGTH = 1000;

/**
 * Strip control characters and trim strings to prevent injection attacks.
 */
function sanitizeString(value, maxLen = MAX_STRING_LENGTH) {
  if (typeof value !== "string") return "";
  return value
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "") // strip control chars
    .trim()
    .slice(0, maxLen);
}

/**
 * Validate a claim analysis request.
 * Required: damages (array), totalCost (number), fraudRiskLevel (string)
 */
function validateAnalyzeClaimRequest(req, res, next) {
  const body = req.body;

  if (!body || typeof body !== "object") {
    return res.status(400).json({ error: "Request body must be a JSON object." });
  }

  const { damages, totalCost, fraudRiskLevel } = body;

  if (!Array.isArray(damages)) {
    return res.status(400).json({ error: "\"damages\" must be an array." });
  }

  if (damages.length === 0) {
    return res.status(400).json({ error: "\"damages\" must contain at least one item." });
  }

  if (damages.length > 30) {
    return res.status(400).json({ error: "\"damages\" exceeds maximum of 30 items." });
  }

  if (typeof totalCost !== "number" || totalCost < 0 || !isFinite(totalCost)) {
    return res.status(400).json({ error: "\"totalCost\" must be a non-negative number." });
  }

  const validRiskLevels = ["LOW", "MEDIUM", "HIGH"];
  if (!validRiskLevels.includes(fraudRiskLevel)) {
    return res
      .status(400)
      .json({ error: `"fraudRiskLevel" must be one of: ${validRiskLevels.join(", ")}.` });
  }

  // Sanitise free-text fields
  if (body.description) {
    body.description = sanitizeString(body.description, MAX_DESCRIPTION_LENGTH);
  }
  if (body.vehicleNumber) {
    body.vehicleNumber = sanitizeString(body.vehicleNumber, 20);
  }

  // Sanitise each damage item's free-text fields
  body.damages = damages.map((d) => ({
    ...d,
    type: sanitizeString(d.type || "", 100),
    part: sanitizeString(d.part || "", 100),
    severity: sanitizeString(d.severity || "", 20),
  }));

  next();
}

/**
 * Validate a general chat / Q&A request.
 * Required: question (non-empty string)
 */
function validateChatRequest(req, res, next) {
  const { question } = req.body || {};

  if (!question || typeof question !== "string") {
    return res.status(400).json({ error: "\"question\" must be a non-empty string." });
  }

  const sanitized = sanitizeString(question, MAX_STRING_LENGTH);
  if (sanitized.length < 3) {
    return res.status(400).json({ error: "\"question\" is too short." });
  }

  req.body.question = sanitized;
  next();
}

module.exports = { validateAnalyzeClaimRequest, validateChatRequest };
