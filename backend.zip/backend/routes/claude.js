/**
 * INSURE AI — Claude API Routes
 *
 * POST /api/claude/analyze-claim  — AI commentary on a claim
 * POST /api/claude/chat           — General claims Q&A
 * GET  /api/claude/health         — Liveness check
 */

"use strict";

const express = require("express");
const router = express.Router();
const { analyzeClaimWithClaude, answerClaimQuestion } = require("../services/claudeService");
const {
  validateAnalyzeClaimRequest,
  validateChatRequest,
} = require("../middleware/validateRequest");

// ──────────────────────────────────────────────────────────
// Helper: map Anthropic SDK errors to user-friendly messages
// ──────────────────────────────────────────────────────────
function handleClaudeError(err, res) {
  console.error("[Claude Error]", err?.message || err);

  // Anthropic SDK exposes a `status` property on API errors
  const status = err?.status || err?.statusCode;

  if (status === 401) {
    return res.status(502).json({
      error: "Claude API key is invalid or missing. Check your backend/.env file.",
    });
  }

  if (status === 429) {
    return res.status(429).json({
      error: "Claude API rate limit reached. Please wait a moment and try again.",
    });
  }

  if (status === 529 || (err?.message || "").includes("overloaded")) {
    return res.status(503).json({
      error: "Claude is temporarily overloaded. Please retry in a few seconds.",
    });
  }

  if ((err?.message || "").includes("ANTHROPIC_API_KEY is not set")) {
    return res.status(503).json({
      error: "Server is not configured. Paste your Anthropic API key into backend/.env.",
    });
  }

  return res.status(500).json({
    error: "An unexpected error occurred while contacting Claude. Please try again.",
  });
}

// ──────────────────────────────────────────────────────────
// GET /api/claude/health
// ──────────────────────────────────────────────────────────
router.get("/health", (req, res) => {
  const keyConfigured = Boolean(
    process.env.ANTHROPIC_API_KEY &&
    !process.env.ANTHROPIC_API_KEY.includes("PASTE_YOUR_KEY")
  );
  res.json({
    status: "ok",
    service: "INSURE AI Claude Backend",
    model: process.env.CLAUDE_MODEL || "claude-3-5-haiku-20241022",
    keyConfigured,
    timestamp: new Date().toISOString(),
  });
});

// ──────────────────────────────────────────────────────────
// POST /api/claude/analyze-claim
// Body: { damages[], totalCost, fraudRiskLevel, fraudRiskScore,
//         fraudFlags[], decisionFromEngine, avgConfidence,
//         vehicleNumber, description }
// ──────────────────────────────────────────────────────────
router.post("/analyze-claim", validateAnalyzeClaimRequest, async (req, res) => {
  try {
    const result = await analyzeClaimWithClaude(req.body);
    return res.json({ success: true, data: result });
  } catch (err) {
    return handleClaudeError(err, res);
  }
});

// ──────────────────────────────────────────────────────────
// POST /api/claude/chat
// Body: { question, context? }
// ──────────────────────────────────────────────────────────
router.post("/chat", validateChatRequest, async (req, res) => {
  const { question, context = {} } = req.body;
  try {
    const result = await answerClaimQuestion(question, context);
    return res.json({ success: true, data: result });
  } catch (err) {
    return handleClaudeError(err, res);
  }
});

module.exports = router;
