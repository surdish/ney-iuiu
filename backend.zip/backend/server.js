/**
 * INSURE AI — Express Backend Server
 *
 * Starts the API server that proxies requests to Claude.
 * The Anthropic API key is read from the .env file and NEVER
 * sent to the frontend.
 *
 * Usage:
 *   npm run dev   — development (auto-restart on file change)
 *   npm start     — production
 */

"use strict";

// Load environment variables FIRST, before any other require
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const claudeRoutes = require("./routes/claude");

const app = express();
const PORT = process.env.PORT || 4000;

// ──────────────────────────────────────────────────────────
// CORS — only allow requests from the configured frontend origin
// ──────────────────────────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_ORIGIN || "http://localhost:5173",
  "http://localhost:5174", // Vite fallback port
  "http://127.0.0.1:5173",
];

app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (curl, Postman, server-to-server)
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);
      callback(new Error(`CORS: origin ${origin} is not allowed.`));
    },
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Accept"],
    credentials: false,
  })
);

// ──────────────────────────────────────────────────────────
// Rate limiting — 60 requests per minute per IP
// ──────────────────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please slow down and try again in a minute." },
});
app.use(limiter);

// ──────────────────────────────────────────────────────────
// Body parsing
// ──────────────────────────────────────────────────────────
app.use(express.json({ limit: "256kb" }));
app.use(express.urlencoded({ extended: false }));

// ──────────────────────────────────────────────────────────
// Routes
// ──────────────────────────────────────────────────────────
app.use("/api/claude", claudeRoutes);

// Root endpoint — useful sanity check
app.get("/", (req, res) => {
  res.json({ service: "INSURE AI Backend", version: "1.0.0", status: "running" });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` });
});

// Global error handler
app.use((err, req, res, _next) => {
  console.error("[Unhandled Error]", err);
  res.status(500).json({ error: "Internal server error." });
});

// ──────────────────────────────────────────────────────────
// Start
// ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  const keyOk =
    process.env.ANTHROPIC_API_KEY &&
    !process.env.ANTHROPIC_API_KEY.includes("PASTE_YOUR_KEY");

  console.log(`\n🚀 INSURE AI Backend running on http://localhost:${PORT}`);
  console.log(`   Model  : ${process.env.CLAUDE_MODEL || "claude-3-5-haiku-20241022"}`);
  console.log(`   API Key: ${keyOk ? "✅ Configured" : "⚠️  NOT SET — paste your key into backend/.env"}`);
  console.log(`   Health : http://localhost:${PORT}/api/claude/health\n`);
});
