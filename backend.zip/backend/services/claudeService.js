/**
 * INSURE AI — Claude Service
 *
 * Thin, reusable wrapper around the Anthropic SDK.
 * All Claude API calls go through this module — never call the SDK directly
 * from routes. This keeps the API key and model config in one place.
 */

"use strict";

const Anthropic = require("@anthropic-ai/sdk");

// Lazy-initialise the client so the module can be required safely even
// before environment variables are loaded (they will be by the time any
// route actually calls the service).
let _client = null;

function getClient() {
  if (!_client) {
    if (!process.env.ANTHROPIC_API_KEY) {
      throw new Error(
        "ANTHROPIC_API_KEY is not set. " +
        "Copy backend/.env.example to backend/.env and paste your key."
      );
    }
    _client = new Anthropic.default({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
  }
  return _client;
}

const DEFAULT_MODEL = process.env.CLAUDE_MODEL || "claude-3-5-haiku-20241022";
const MAX_TOKENS = 1024;

/**
 * Send a single user message to Claude and return the text response.
 *
 * @param {string} systemPrompt  - The system instruction for Claude.
 * @param {string} userMessage   - The user-facing message / claim payload.
 * @param {object} [options]     - Optional overrides { model, maxTokens }.
 * @returns {Promise<{ text: string }>}
 */
async function callClaude(systemPrompt, userMessage, options = {}) {
  const client = getClient();
  const model = options.model || DEFAULT_MODEL;
  const maxTokens = options.maxTokens || MAX_TOKENS;

  const message = await client.messages.create({
    model,
    max_tokens: maxTokens,
    system: systemPrompt,
    messages: [{ role: "user", content: userMessage }],
  });

  const text =
    message.content?.[0]?.type === "text"
      ? message.content[0].text
      : "";

  return { text };
}

/**
 * Analyse a claim payload and return an AI commentary.
 *
 * @param {object} claimPayload - Structured claim data from the frontend.
 * @returns {Promise<{ commentary: string, confidence: string, recommendation: string }>}
 */
async function analyzeClaimWithClaude(claimPayload) {
  const {
    damages = [],
    totalCost = 0,
    fraudRiskLevel = "LOW",
    fraudRiskScore = 0,
    fraudFlags = [],
    decisionFromEngine = "APPROVED",
    avgConfidence = 0,
    vehicleNumber = "",
    description = "",
  } = claimPayload;

  const systemPrompt = `You are an expert motor insurance claims assessor working for INSURE AI.
Your role is to review AI-generated vehicle damage assessment data and produce a concise,
professional plain-English commentary for the claims officer handling the case.

Rules:
- Be factual, concise, and professional. No marketing language.
- Use Indian Rupees (₹) for all amounts.
- Keep total response under 280 words.
- Return ONLY valid JSON with these exact keys:
  {
    "commentary": "<2-3 sentence summary of the claim>",
    "keyFindings": ["<finding 1>", "<finding 2>", "<finding 3>"],
    "recommendation": "<one sentence actionable recommendation>",
    "confidenceAssessment": "<one sentence on overall data quality>"
  }
- Do not add markdown fences, preamble, or extra keys.`;

  const damageList = damages
    .map(
      (d) =>
        `- ${d.type} (${d.part}): severity ${d.severity}, confidence ${d.confidence}%, est. ₹${d.estCost?.toLocaleString("en-IN") || "N/A"}`
    )
    .join("\n");

  const userMessage = `Claim Summary:
Vehicle: ${vehicleNumber || "Not provided"}
Incident description: ${description || "Not provided"}

Detected Damages (${damages.length} item(s)):
${damageList || "No damage items detected"}

Financial Summary:
- Total estimated repair cost: ₹${totalCost.toLocaleString("en-IN")}
- Average detection confidence: ${avgConfidence.toFixed(1)}%

Fraud Analysis:
- Risk level: ${fraudRiskLevel}
- Risk score: ${fraudRiskScore}/100
- Metadata flags: ${fraudFlags.length > 0 ? fraudFlags.join("; ") : "None"}

Engine Decision: ${decisionFromEngine}

Please provide your professional claims assessment in the required JSON format.`;

  const { text } = await callClaude(systemPrompt, userMessage);

  // Parse the JSON response from Claude
  let parsed;
  try {
    // Strip accidental markdown fences if Claude adds them
    const clean = text.replace(/```(?:json)?/gi, "").replace(/```/g, "").trim();
    parsed = JSON.parse(clean);
  } catch {
    // Graceful fallback if JSON parsing fails
    parsed = {
      commentary: text.slice(0, 400),
      keyFindings: [],
      recommendation: "Please review the raw analysis above.",
      confidenceAssessment: "Structured parsing failed; raw response shown.",
    };
  }

  return parsed;
}

/**
 * Answer a general claims-related question from the user.
 *
 * @param {string} question  - The user's question text.
 * @param {object} [context] - Optional claim context to ground the answer.
 * @returns {Promise<{ answer: string }>}
 */
async function answerClaimQuestion(question, context = {}) {
  const systemPrompt = `You are a helpful motor insurance claims assistant for INSURE AI, an AI-powered
vehicle damage assessment platform for the Indian market.
Answer questions clearly and concisely. Use ₹ for amounts. Keep answers under 180 words.
If a question is outside insurance or vehicle damage topics, politely say you can only help with claims.`;

  const contextStr = Object.keys(context).length
    ? `\nClaim context: ${JSON.stringify(context, null, 2)}\n`
    : "";

  const { text } = await callClaude(systemPrompt, `${contextStr}Question: ${question}`);
  return { answer: text };
}

module.exports = {
  analyzeClaimWithClaude,
  answerClaimQuestion,
};
