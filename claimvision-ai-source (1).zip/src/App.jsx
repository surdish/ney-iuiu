import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { ClaimsProvider } from "./lib/ClaimsContext";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ClaimUpload from "./pages/ClaimUpload";
import ClaimResult from "./pages/ClaimResult";
import ClaimHistory from "./pages/ClaimHistory";
import ClaimDetails from "./pages/ClaimDetails";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import AdminDashboard from "./pages/AdminDashboard";
import About from "./pages/About";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";

function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (!hash) window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-ink">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ClaimsProvider>
        <ScrollToTop />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/claim/new" element={<ClaimUpload />} />
            <Route path="/claim/result" element={<ClaimResult />} />
            <Route path="/claims/history" element={<ClaimHistory />} />
            <Route path="/claims/:id" element={<ClaimDetails />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/admin" element={<AdminDashboard initialTab="overview" />} />
            <Route path="/admin/analytics" element={<AdminDashboard initialTab="analytics" />} />
            <Route path="/admin/fraud" element={<AdminDashboard initialTab="fraud" />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </ClaimsProvider>
    </BrowserRouter>
  );
}
