import { Link } from "react-router-dom";
import { ScanEye, Globe, Share2, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-line bg-panel/60">
      <div className="max-w-7xl mx-auto px-6 py-14 grid grid-cols-2 md:grid-cols-5 gap-10">
        <div className="col-span-2">
          <Link to="/" className="flex items-center gap-2 mb-4">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-400">
              <ScanEye size={16} className="text-ink" strokeWidth={2.5} />
            </span>
            <span className="font-display font-semibold text-frost">
              ClaimVision AI
            </span>
          </Link>
          <p className="text-sm text-mist max-w-xs leading-relaxed">
            Explainable computer vision for vehicle damage assessment,
            repair cost estimation, and fraud-aware claim decisions.
          </p>
          <div className="flex gap-3 mt-5">
            {[Globe, Share2, Mail].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-9 h-9 rounded-lg glass flex items-center justify-center text-mist hover:text-cyan-300 transition-colors"
              >
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-frost mb-4">Company</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li><Link to="/about" className="hover:text-cyan-300 transition-colors">About</Link></li>
            <li><a href="#" className="hover:text-cyan-300 transition-colors">Privacy</a></li>
            <li><a href="#" className="hover:text-cyan-300 transition-colors">Terms</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-frost mb-4">Product</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li><Link to="/dashboard" className="hover:text-cyan-300 transition-colors">Dashboard</Link></li>
            <li><Link to="/claim/new" className="hover:text-cyan-300 transition-colors">Start Claim</Link></li>
            <li><a href="/#pricing" className="hover:text-cyan-300 transition-colors">Pricing</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-frost mb-4">Support</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li><Link to="/contact" className="hover:text-cyan-300 transition-colors">Contact</Link></li>
            <li><a href="/#faq" className="hover:text-cyan-300 transition-colors">FAQ</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line">
        <div className="max-w-7xl mx-auto px-6 py-5 text-xs text-mist/70 flex flex-col sm:flex-row justify-between gap-2">
          <span>© 2026 ClaimVision AI. Built for demonstration purposes.</span>
          <span>Not affiliated with any insurer. All figures are simulated.</span>
        </div>
      </div>
    </footer>
  );
}
