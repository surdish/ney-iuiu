import { useState } from "react";
import { Mail, MapPin, Phone, Send } from "lucide-react";
import { GlassCard, SectionEyebrow, PrimaryButton, FadeIn } from "../components/ui";

export default function Contact() {
  const [sent, setSent] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-5xl mx-auto">
        <FadeIn className="text-center mb-14">
          <SectionEyebrow><span className="mx-auto">Contact</span></SectionEyebrow>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
            Let&apos;s talk about your claims pipeline
          </h1>
        </FadeIn>

        <div className="grid lg:grid-cols-5 gap-8">
          <FadeIn delay={0.05} className="lg:col-span-2 space-y-4">
            {[
              { icon: Mail, label: "Email", value: "hello@claimvision.ai" },
              { icon: Phone, label: "Phone", value: "+91 44 4000 1234" },
              { icon: MapPin, label: "Office", value: "Chennai, Tamil Nadu, India" },
            ].map((c) => (
              <GlassCard key={c.label} className="p-6 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-700/60 to-cyan-400/20 border border-cyan-400/20 flex items-center justify-center shrink-0">
                  <c.icon size={16} className="text-cyan-300" />
                </div>
                <div>
                  <div className="text-xs text-mist">{c.label}</div>
                  <div className="text-sm text-frost font-medium">{c.value}</div>
                </div>
              </GlassCard>
            ))}
          </FadeIn>

          <FadeIn delay={0.1} className="lg:col-span-3">
            <GlassCard className="p-8">
              {sent ? (
                <div className="text-center py-10">
                  <Send size={28} className="text-cyan-300 mx-auto mb-4" />
                  <h3 className="font-display text-lg font-semibold text-frost">Message sent</h3>
                  <p className="text-sm text-mist mt-2">We&apos;ll get back to you within one business day.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-xs font-medium text-mist mb-2 block">Name</label>
                      <input required className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50" placeholder="Your name" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-mist mb-2 block">Email</label>
                      <input required type="email" className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50" placeholder="you@company.com" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-mist mb-2 block">Message</label>
                    <textarea required rows={5} className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50 resize-none" placeholder="Tell us about your claims volume..." />
                  </div>
                  <PrimaryButton type="submit" className="w-full sm:w-auto">
                    Send Message <Send size={15} />
                  </PrimaryButton>
                </form>
              )}
            </GlassCard>
          </FadeIn>
        </div>
      </div>
    </div>
  );
}
