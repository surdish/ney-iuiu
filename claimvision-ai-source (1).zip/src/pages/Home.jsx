import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ScanEye,
  Wallet,
  ShieldAlert,
  BrainCircuit,
  ClipboardCheck,
  LayoutDashboard,
  UploadCloud,
  ScanSearch,
  Ruler,
  FileSearch2,
  Sparkles,
  FileDown,
  Play,
  ArrowRight,
  Building2,
  Landmark,
  Car,
  Warehouse,
  Wrench,
  Check,
  ChevronDown,
} from "lucide-react";
import {
  GlassCard,
  SectionEyebrow,
  AnimatedCounter,
  FadeIn,
  PrimaryButton,
  GhostButton,
  DecisionBadge,
  RiskBadge,
  SeverityBadge,
} from "../components/ui";
import ScanVisual from "../components/ScanVisual";

const stats = [
  { value: 98, suffix: "%", label: "Detection Accuracy" },
  { value: 10, suffix: "s", label: "Avg. Processing Time" },
  { value: 90, suffix: "%", label: "Faster Claim Turnaround" },
  { value: 50, suffix: "K+", label: "Claims Processed" },
];

const trustedBy = [
  { icon: Landmark, label: "Government" },
  { icon: Building2, label: "Insurance" },
  { icon: Car, label: "Automobile" },
  { icon: Warehouse, label: "Dealership" },
  { icon: Wrench, label: "Repair Centers" },
];

const features = [
  {
    icon: ScanSearch,
    title: "AI Damage Detection",
    desc: "Detect dents, scratches, cracks, broken glass, and bumper damage using computer vision trained on labeled repair data.",
  },
  {
    icon: Wallet,
    title: "Repair Cost Estimation",
    desc: "Generate repair cost ranges from standardized parts and labor pricing tables, matched to detected damage severity.",
  },
  {
    icon: ShieldAlert,
    title: "Fraud Detection",
    desc: "Duplicate image detection, EXIF metadata analysis, and statistical anomaly checks flag suspicious claims automatically.",
  },
  {
    icon: BrainCircuit,
    title: "Explainable AI",
    desc: "Every recommendation ships with a human-readable report, a confidence score, and the reasoning behind the decision.",
  },
  {
    icon: ClipboardCheck,
    title: "Claim Recommendation",
    desc: "Each claim resolves to a clear outcome — Approve, Manual Review, or Reject — with the evidence that led there.",
  },
  {
    icon: LayoutDashboard,
    title: "Analytics Dashboard",
    desc: "Track claim history, fraud alerts, and processing analytics from a single operations dashboard.",
  },
];

const steps = [
  { icon: UploadCloud, title: "Upload Vehicle Images", desc: "Add photos of the damaged vehicle from any angle." },
  { icon: FileSearch2, title: "AI Quality Check", desc: "Images are checked for clarity, angle, and completeness." },
  { icon: ScanSearch, title: "Damage Detection", desc: "Computer vision localizes and classifies every damage region." },
  { icon: Ruler, title: "Repair Cost Estimation", desc: "Standardized pricing tables generate a cost range per part." },
  { icon: ShieldAlert, title: "Fraud Detection", desc: "Duplicate, metadata, and anomaly checks run in parallel." },
  { icon: BrainCircuit, title: "AI Recommendation", desc: "An explainable decision is generated with a confidence score." },
  { icon: FileDown, title: "Download Claim Report", desc: "A complete, shareable report is ready in seconds." },
];

const pricingTiers = [
  {
    name: "Starter",
    price: "₹0",
    period: "/ month",
    desc: "For small repair shops evaluating the platform.",
    features: ["50 claims / month", "Core damage detection", "Standard cost estimation", "Email support"],
    highlight: false,
  },
  {
    name: "Professional",
    price: "₹24,999",
    period: "/ month",
    desc: "For growing insurers and claim networks.",
    features: [
      "2,000 claims / month",
      "Full fraud detection suite",
      "Explainable AI reports",
      "Admin analytics dashboard",
      "Priority support",
    ],
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For large insurers with custom pricing tables.",
    features: [
      "Unlimited claims",
      "Custom model tuning",
      "Dedicated infrastructure",
      "SLA-backed support",
      "On-prem / VPC deployment",
    ],
    highlight: false,
  },
];

const testimonials = [
  {
    quote: "Manual inspection time on straightforward claims dropped dramatically once triage moved to the assessor.",
    name: "Claims Operations Lead",
    role: "Regional Insurance Company",
  },
  {
    quote: "The confidence score and reasoning make it easy for our officers to trust — and double-check — every recommendation.",
    name: "Senior Claims Officer",
    role: "Motor Insurance Division",
  },
  {
    quote: "Uploading photos after an accident and getting a clear next step within seconds took a lot of stress out of the process.",
    name: "Policyholder",
    role: "Vehicle Owner",
  },
];

const faqs = [
  {
    q: "How accurate is the AI?",
    a: "The detection pipeline reports an average of 98% accuracy on labeled validation sets across common damage classes such as dents, scratches, cracks, and shattered components. Every prediction also carries its own confidence score so lower-certainty results can be routed to manual review instead of being silently accepted.",
  },
  {
    q: "How is repair cost estimated?",
    a: "Detected damage is matched against standardized parts and labor pricing tables by part, severity, and damage type. The system returns a cost range rather than a single number, reflecting the natural variance in repair estimates.",
  },
  {
    q: "How does fraud detection work?",
    a: "Three checks run in parallel: perceptual duplicate-image detection across the claim's photo set, EXIF metadata analysis for timestamp and location inconsistencies, and statistical anomaly detection comparing claimed cost against expected cost for the detected severity.",
  },
  {
    q: "Is my data secure?",
    a: "Uploaded images and claim data are encrypted in transit and at rest, and access is scoped by role — policyholders, repair partners, and claims officers each see only what they need.",
  },
];

export default function Home() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState(0);

  return (
    <div>
      {/* HERO */}
      <section className="relative pt-40 pb-24 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
        <div className="absolute inset-0 grid-bg opacity-[0.15] pointer-events-none" />
        <div className="max-w-7xl mx-auto relative grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <FadeIn>
              <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-cyan-300 mb-6 px-3 py-1.5 rounded-full border border-cyan-400/20 bg-cyan-400/5">
                <Sparkles size={12} /> Computer Vision for Claims
              </span>
            </FadeIn>
            <FadeIn delay={0.05}>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.4rem] leading-[1.08] font-semibold tracking-tight text-frost">
                AI Powered Vehicle Damage Assessment{" "}
                <span className="text-gradient">&amp; Smart Insurance Claims</span>
              </h1>
            </FadeIn>
            <FadeIn delay={0.1}>
              <p className="mt-6 text-lg text-mist leading-relaxed max-w-xl">
                Upload damaged vehicle images and let AI instantly detect
                damages, estimate repair costs, identify fraud, and generate
                explainable insurance claim recommendations.
              </p>
            </FadeIn>
            <FadeIn delay={0.15}>
              <div className="mt-9 flex flex-wrap gap-4">
                <PrimaryButton onClick={() => navigate("/claim/new")}>
                  Start Claim <ArrowRight size={16} />
                </PrimaryButton>
                <GhostButton onClick={() => navigate("/dashboard")}>
                  <Play size={16} /> Watch Demo
                </GhostButton>
              </div>
            </FadeIn>

            <FadeIn delay={0.25}>
              <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6">
                {stats.map((s) => (
                  <div key={s.label}>
                    <div className="font-display text-2xl sm:text-3xl font-semibold text-frost">
                      <AnimatedCounter value={s.value} suffix={s.suffix} />
                    </div>
                    <div className="text-xs text-mist mt-1">{s.label}</div>
                  </div>
                ))}
              </div>
            </FadeIn>
          </div>

          <FadeIn delay={0.2} y={40}>
            <ScanVisual />
          </FadeIn>
        </div>
      </section>

      {/* TRUSTED BY */}
      <section className="px-6 py-14 border-y border-line bg-panel/40">
        <div className="max-w-7xl mx-auto">
          <p className="text-center text-xs font-mono uppercase tracking-[0.2em] text-mist/60 mb-8">
            Built for every stakeholder in the claims lifecycle
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-8">
            {trustedBy.map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex flex-col items-center gap-2 text-mist/50 hover:text-cyan-300/70 transition-colors"
              >
                <Icon size={26} strokeWidth={1.5} />
                <span className="text-xs font-medium">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="px-6 py-28">
        <div className="max-w-7xl mx-auto">
          <FadeIn>
            <SectionEyebrow>Platform</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost max-w-2xl">
              Everything an insurer needs to resolve a claim without a site visit
            </h2>
          </FadeIn>
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <FadeIn key={f.title} delay={i * 0.05}>
                <GlassCard hover className="p-7 h-full">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-700/60 to-cyan-400/20 border border-cyan-400/20 flex items-center justify-center mb-5">
                    <f.icon size={20} className="text-cyan-300" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-frost mb-2">
                    {f.title}
                  </h3>
                  <p className="text-sm text-mist leading-relaxed">{f.desc}</p>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-7xl mx-auto">
          <FadeIn>
            <SectionEyebrow>Process</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost max-w-2xl">
              From upload to decision in seven explainable steps
            </h2>
          </FadeIn>

          <div className="mt-16 relative">
            <div className="hidden lg:block absolute top-0 bottom-0 left-[27px] w-px bg-gradient-to-b from-cyan-400/40 via-line to-transparent" />
            <div className="space-y-10">
              {steps.map((s, i) => (
                <FadeIn key={s.title} delay={i * 0.04}>
                  <div className="flex items-start gap-6">
                    <div className="relative shrink-0 w-14 h-14 rounded-2xl glass flex items-center justify-center">
                      <s.icon size={22} className="text-cyan-300" />
                      <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-blue-600 text-[10px] font-mono flex items-center justify-center text-frost border border-ink">
                        {i + 1}
                      </span>
                    </div>
                    <div className="pt-2">
                      <h4 className="font-display font-semibold text-frost text-base">
                        {s.title}
                      </h4>
                      <p className="text-sm text-mist mt-1">{s.desc}</p>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DEMO DASHBOARD PREVIEW */}
      <section className="px-6 py-28">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-14 items-center">
          <FadeIn>
            <SectionEyebrow>Live Preview</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-5">
              See exactly what the assessor sees
            </h2>
            <p className="text-mist leading-relaxed mb-8 max-w-lg">
              Every claim result includes the detected damage regions, an
              estimated repair cost, a confidence score, and a plain-English
              recommendation your team can act on immediately.
            </p>
            <GhostButton onClick={() => navigate("/claim/new")}>
              Try it yourself <ArrowRight size={16} />
            </GhostButton>
          </FadeIn>

          <FadeIn delay={0.1}>
            <GlassCard className="p-6">
              <div className="flex items-center justify-between mb-5">
                <span className="text-xs font-mono text-mist">CLAIM #CV-10245</span>
                <DecisionBadge decision="APPROVED" />
              </div>
              <div className="space-y-3 mb-5">
                <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-white/[0.02] border border-line">
                  <span className="text-sm text-frost">Front Bumper Dent</span>
                  <span className="text-sm font-mono text-cyan-300">92%</span>
                </div>
                <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-white/[0.02] border border-line">
                  <span className="text-sm text-frost">Headlight Broken</span>
                  <span className="text-sm font-mono text-cyan-300">89%</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Est. Cost</div>
                  <div className="font-mono text-frost text-sm">₹24,500</div>
                </div>
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Confidence</div>
                  <div className="font-mono text-frost text-sm">95%</div>
                </div>
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Fraud Risk</div>
                  <div className="font-mono text-ok text-sm">LOW</div>
                </div>
              </div>
            </GlassCard>
          </FadeIn>
        </div>
      </section>

      {/* CLAIM UPLOAD TEASER */}
      <section className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-4xl mx-auto text-center">
          <FadeIn>
            <SectionEyebrow>Start a Claim</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-5">
              Ready when your images are
            </h2>
            <p className="text-mist mb-10 max-w-xl mx-auto">
              Drag and drop multiple angles of the vehicle, add the incident
              details, and receive a full assessment in seconds.
            </p>
          </FadeIn>
          <FadeIn delay={0.1}>
            <GlassCard
              className="p-14 border-dashed border-2 border-line hover:border-cyan-400/40 transition-colors cursor-pointer"
              onClick={() => navigate("/claim/new")}
            >
              <UploadCloud size={36} className="text-cyan-300 mx-auto mb-4" />
              <p className="text-frost font-medium">Click to start your claim upload</p>
              <p className="text-sm text-mist mt-1">JPG, PNG — up to 10 images</p>
            </GlassCard>
          </FadeIn>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="px-6 py-28">
        <div className="max-w-7xl mx-auto">
          <FadeIn className="text-center max-w-2xl mx-auto">
            <SectionEyebrow>
              <span className="mx-auto">Pricing</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Plans that scale with claim volume
            </h2>
          </FadeIn>

          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {pricingTiers.map((tier, i) => (
              <FadeIn key={tier.name} delay={i * 0.06}>
                <GlassCard
                  className={`p-8 h-full flex flex-col ${
                    tier.highlight ? "border-cyan-400/40 shadow-glow relative" : ""
                  }`}
                >
                  {tier.highlight && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[10px] font-mono uppercase tracking-wide bg-gradient-to-r from-cyan-300 to-blue-500 text-ink px-3 py-1 rounded-full font-semibold">
                      Most Popular
                    </span>
                  )}
                  <h3 className="font-display text-xl font-semibold text-frost">{tier.name}</h3>
                  <p className="text-sm text-mist mt-2 mb-6">{tier.desc}</p>
                  <div className="mb-6">
                    <span className="font-display text-3xl font-semibold text-frost">{tier.price}</span>
                    <span className="text-mist text-sm">{tier.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8 flex-1">
                    {tier.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm text-mist">
                        <Check size={16} className="text-cyan-300 mt-0.5 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => navigate("/register")}
                    className={
                      tier.highlight
                        ? "w-full text-sm font-semibold text-ink bg-gradient-to-r from-cyan-300 to-blue-500 hover:opacity-90 rounded-xl px-6 py-3 transition-opacity"
                        : "w-full text-sm font-semibold text-frost border border-line hover:border-cyan-400/50 rounded-xl px-6 py-3 transition-colors"
                    }
                  >
                    Get Started
                  </button>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-7xl mx-auto">
          <FadeIn className="text-center max-w-2xl mx-auto">
            <SectionEyebrow>
              <span className="mx-auto">Testimonials</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Trusted across the claims lifecycle
            </h2>
          </FadeIn>
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <FadeIn key={t.name} delay={i * 0.06}>
                <GlassCard className="p-7 h-full flex flex-col">
                  <p className="text-mist text-sm leading-relaxed flex-1">
                    &ldquo;{t.quote}&rdquo;
                  </p>
                  <div className="mt-6 pt-5 border-t border-line">
                    <div className="text-sm font-semibold text-frost">{t.name}</div>
                    <div className="text-xs text-mist">{t.role}</div>
                  </div>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="px-6 py-28">
        <div className="max-w-3xl mx-auto">
          <FadeIn className="text-center mb-14">
            <SectionEyebrow>
              <span className="mx-auto">FAQ</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Frequently asked questions
            </h2>
          </FadeIn>
          <div className="space-y-3">
            {faqs.map((f, i) => (
              <FadeIn key={f.q} delay={i * 0.04}>
                <GlassCard className="overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? -1 : i)}
                    className="w-full flex items-center justify-between px-6 py-5 text-left"
                  >
                    <span className="font-medium text-frost">{f.q}</span>
                    <ChevronDown
                      size={18}
                      className={`text-cyan-300 transition-transform shrink-0 ml-4 ${
                        openFaq === i ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  <motion.div
                    initial={false}
                    animate={{ height: openFaq === i ? "auto" : 0 }}
                    className="overflow-hidden"
                  >
                    <p className="px-6 pb-5 text-sm text-mist leading-relaxed">{f.a}</p>
                  </motion.div>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="px-6 pb-28">
        <div className="max-w-5xl mx-auto">
          <FadeIn>
            <GlassCard className="p-14 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
              <div className="relative">
                <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-4">
                  Ready to accelerate your claims process?
                </h2>
                <p className="text-mist mb-8 max-w-lg mx-auto">
                  Start your first claim assessment in under a minute — no
                  manual inspection required.
                </p>
                <PrimaryButton onClick={() => navigate("/claim/new")}>
                  Start Claim <ArrowRight size={16} />
                </PrimaryButton>
              </div>
            </GlassCard>
          </FadeIn>
        </div>
      </section>
    </div>
  );
}
