import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ScanEye, Mail, Lock, ArrowRight } from "lucide-react";
import { GlassCard, PrimaryButton, FadeIn } from "../components/ui";

export default function Login() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => navigate("/dashboard"), 700);
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-28 pb-16 relative">
      <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
      <FadeIn className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-400 shadow-glow">
              <ScanEye size={20} className="text-ink" strokeWidth={2.5} />
            </span>
          </Link>
          <h1 className="font-display text-2xl font-semibold text-frost">Welcome back</h1>
          <p className="text-sm text-mist mt-2">Log in to access your claims dashboard</p>
        </div>

        <GlassCard className="p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-xs font-medium text-mist mb-2 block">Email address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                <input
                  type="email"
                  required
                  placeholder="you@company.com"
                  className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-mist mb-2 block">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                />
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 text-mist">
                <input type="checkbox" className="accent-cyan-400" /> Remember me
              </label>
              <a href="#" className="text-cyan-300 hover:text-cyan-200">Forgot password?</a>
            </div>
            <PrimaryButton type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in..." : "Login"} {!loading && <ArrowRight size={16} />}
            </PrimaryButton>
          </form>
        </GlassCard>

        <p className="text-center text-sm text-mist mt-6">
          Don&apos;t have an account?{" "}
          <Link to="/register" className="text-cyan-300 hover:text-cyan-200 font-medium">
            Register
          </Link>
        </p>
      </FadeIn>
    </div>
  );
}
