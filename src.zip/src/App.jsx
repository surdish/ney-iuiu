import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { ClaimsProvider } from "./lib/ClaimsContext";
import ProtectedRoute from "./components/ProtectedRoute";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ClaimUpload from "./pages/ClaimUpload";
import ClaimResult from "./pages/ClaimResult";
import ClaimHistory from "./pages/ClaimHistory";
import ClaimDetails from "./pages/ClaimDetails";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import AdminDashboard from "./pages/AdminDashboard";
import About from "./pages/About";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";

function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (!hash) window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-ink">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ClaimsProvider>
        <ScrollToTop />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            {/* Protected Routes */}
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/claim/new" element={<ProtectedRoute><ClaimUpload /></ProtectedRoute>} />
            <Route path="/claim/result" element={<ProtectedRoute><ClaimResult /></ProtectedRoute>} />
            <Route path="/claims/history" element={<ProtectedRoute><ClaimHistory /></ProtectedRoute>} />
            <Route path="/claims/:id" element={<ProtectedRoute><ClaimDetails /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
            <Route path="/admin" element={<ProtectedRoute><AdminDashboard initialTab="overview" /></ProtectedRoute>} />
            <Route path="/admin/analytics" element={<ProtectedRoute><AdminDashboard initialTab="analytics" /></ProtectedRoute>} />
            <Route path="/admin/fraud" element={<ProtectedRoute><AdminDashboard initialTab="fraud" /></ProtectedRoute>} />
            
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </ClaimsProvider>
    </BrowserRouter>
  );
}
