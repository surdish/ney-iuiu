import { useState, useEffect } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ScanEye, Menu, X } from "lucide-react";
import { useClaims } from "../lib/ClaimsContext";

const links = [
  { to: "/", label: "Home", end: true },
  { to: "/#features", label: "Features" },
  { to: "/#how-it-works", label: "How It Works" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/#pricing", label: "Pricing" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { user, logout } = useClaims();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "glass shadow-card" : "bg-transparent"
      }`}
    >
      <nav className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2 group">
          <span className="relative flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-400 shadow-glow">
            <ScanEye size={18} className="text-ink" strokeWidth={2.5} />
          </span>
          <span className="font-display font-semibold text-lg tracking-tight text-frost">
            INSURE <span className="text-cyan-300">AI</span>
          </span>
        </Link>

        <div className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <NavLink
              key={l.label}
              to={l.to}
              end={l.end}
              className="text-sm text-mist hover:text-frost transition-colors font-medium"
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-sm text-mist">
                Hello, <span className="text-frost font-medium">{user.name}</span>
              </span>
              <button
                onClick={() => navigate("/profile")}
                className="text-sm font-medium text-frost border border-line hover:border-cyan-400/50 rounded-lg px-4 py-2 transition-colors"
              >
                Profile
              </button>
              <button
                onClick={() => {
                  logout();
                  navigate("/login");
                }}
                className="text-sm font-medium text-red-400 hover:text-red-300 transition-colors px-4 py-2"
              >
                Logout
              </button>
            </div>
          ) : (
            <>
              <button
                onClick={() => navigate("/login")}
                className="text-sm font-medium text-mist hover:text-frost transition-colors px-4 py-2"
              >
                Login
              </button>
              <button
                onClick={() => navigate("/register")}
                className="text-sm font-medium text-frost border border-line hover:border-cyan-400/50 rounded-lg px-4 py-2 transition-colors"
              >
                Register
              </button>
              <button
                onClick={() => navigate("/claim/new")}
                className="text-sm font-semibold text-ink bg-gradient-to-r from-cyan-300 to-blue-500 hover:opacity-90 rounded-lg px-4 py-2 transition-opacity shadow-glow"
              >
                Get Started
              </button>
            </>
          )}
        </div>

        <button
          className="lg:hidden text-frost"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden glass overflow-hidden"
          >
            <div className="flex flex-col px-6 py-4 gap-4">
              {links.map((l) => (
                <NavLink
                  key={l.label}
                  to={l.to}
                  onClick={() => setOpen(false)}
                  className="text-sm text-mist hover:text-frost font-medium"
                >
                  {l.label}
                </NavLink>
              ))}
              {user ? (
                <div className="flex flex-col gap-3 pt-2">
                  <div className="text-sm text-mist px-2">
                    Logged in as <span className="text-frost font-medium">{user.name}</span>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => { setOpen(false); navigate("/profile"); }}
                      className="flex-1 text-sm font-medium text-mist border border-line rounded-lg px-4 py-2"
                    >
                      Profile
                    </button>
                    <button
                      onClick={() => {
                        setOpen(false);
                        logout();
                        navigate("/login");
                      }}
                      className="flex-1 text-sm font-medium text-red-400 border border-red-500/30 rounded-lg px-4 py-2"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => { setOpen(false); navigate("/login"); }}
                    className="flex-1 text-sm font-medium text-mist border border-line rounded-lg px-4 py-2"
                  >
                    Login
                  </button>
                  <button
                    onClick={() => { setOpen(false); navigate("/claim/new"); }}
                    className="flex-1 text-sm font-semibold text-ink bg-gradient-to-r from-cyan-300 to-blue-500 rounded-lg px-4 py-2"
                  >
                    Get Started
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
