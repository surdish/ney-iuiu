import { Navigate, useLocation } from "react-router-dom";
import { useClaims } from "../lib/ClaimsContext";

export default function ProtectedRoute({ children }) {
  const { user, loading } = useClaims();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ink">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-sm text-mist font-medium">Verifying session...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    // Redirect to login but save the original route they tried to visit
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
