import { motion } from "framer-motion";

const boxes = [
  { x: 12, y: 58, w: 20, h: 16, label: "Bumper Dent", conf: 94, delay: 0.6 },
  { x: 62, y: 30, w: 18, h: 14, label: "Headlight", conf: 89, delay: 1.1 },
  { x: 38, y: 20, w: 16, h: 12, label: "Windshield", conf: 91, delay: 1.6 },
];

export default function ScanVisual() {
  return (
    <div className="relative w-full aspect-[4/3] rounded-3xl glass shadow-glow overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40" />

      {/* Car silhouette */}
      <svg
        viewBox="0 0 400 300"
        className="absolute inset-0 w-full h-full p-10"
        fill="none"
      >
        <path
          d="M40 190 C40 170 55 165 75 160 L100 130 C110 118 125 112 145 112 L250 112 C270 112 285 118 295 130 L320 160 C340 165 355 170 355 190 L355 210 C355 218 349 224 341 224 L320 224 C320 208 306 195 290 195 C274 195 260 208 260 224 L140 224 C140 208 126 195 110 195 C94 195 80 208 80 224 L59 224 C51 224 45 218 45 210 Z"
          stroke="#3FE6F0"
          strokeWidth="1.5"
          strokeOpacity="0.55"
          fill="rgba(63,230,240,0.03)"
        />
        <circle cx="110" cy="224" r="24" stroke="#3FE6F0" strokeOpacity="0.4" strokeWidth="1.5" fill="none" />
        <circle cx="290" cy="224" r="24" stroke="#3FE6F0" strokeOpacity="0.4" strokeWidth="1.5" fill="none" />
        <line x1="145" y1="112" x2="140" y2="160" stroke="#3FE6F0" strokeOpacity="0.35" strokeWidth="1" />
        <line x1="255" y1="112" x2="260" y2="160" stroke="#3FE6F0" strokeOpacity="0.35" strokeWidth="1" />
      </svg>

      {/* Scan line */}
      <motion.div
        className="absolute left-0 right-0 h-24 bg-gradient-to-b from-cyan-400/0 via-cyan-400/25 to-cyan-400/0"
        initial={{ top: "5%" }}
        animate={{ top: ["5%", "85%", "5%"] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Bounding boxes */}
      {boxes.map((b, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: b.delay, duration: 0.4, repeat: Infinity, repeatDelay: 3.6, repeatType: "reverse" }}
          className="absolute border-2 border-cyan-300 rounded-md"
          style={{
            left: `${b.x}%`,
            top: `${b.y}%`,
            width: `${b.w}%`,
            height: `${b.h}%`,
          }}
        >
          <span className="absolute -top-6 left-0 whitespace-nowrap text-[10px] font-mono bg-cyan-300 text-ink px-1.5 py-0.5 rounded">
            {b.label} {b.conf}%
          </span>
        </motion.div>
      ))}

      {/* corner readouts */}
      <div className="absolute bottom-4 left-4 text-[10px] font-mono text-cyan-300/70 space-y-0.5">
        <div>FRAME 0142 / MODEL v3.2</div>
        <div>INFERENCE: 380ms</div>
      </div>
      <div className="absolute top-4 right-4 flex items-center gap-1.5 text-[10px] font-mono text-ok">
        <span className="w-1.5 h-1.5 rounded-full bg-ok animate-pulse-slow" />
        LIVE ANALYSIS
      </div>
    </div>
  );
}
