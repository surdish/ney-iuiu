import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

export function GlassCard({ children, className = "", hover = false, ...props }) {
  return (
    <div
      className={`glass rounded-2xl shadow-card ${
        hover ? "transition-transform duration-300 hover:-translate-y-1 hover:shadow-glow" : ""
      } ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function SectionEyebrow({ children }) {
  return (
    <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-cyan-300 mb-4">
      <span className="w-6 h-px bg-cyan-400/60" />
      {children}
    </span>
  );
}

export function AnimatedCounter({ value, suffix = "", prefix = "", decimals = 0 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const duration = 1400;
    const startTime = performance.now();
    function tick(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(value * eased);
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }, [inView, value]);

  return (
    <span ref={ref}>
      {prefix}
      {display.toFixed(decimals)}
      {suffix}
    </span>
  );
}

export function DecisionBadge({ decision }) {
  const styles = {
    APPROVED: "bg-ok/10 text-ok border-ok/30",
    "MANUAL REVIEW": "bg-warn/10 text-warn border-warn/30",
    REJECTED: "bg-bad/10 text-bad border-bad/30",
  };
  return (
    <span
      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-mono font-semibold border ${styles[decision]}`}
    >
      {decision}
    </span>
  );
}

export function RiskBadge({ level }) {
  const styles = {
    LOW: "bg-ok/10 text-ok border-ok/30",
    MEDIUM: "bg-warn/10 text-warn border-warn/30",
    HIGH: "bg-bad/10 text-bad border-bad/30",
  };
  return (
    <span
      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-mono font-semibold border ${styles[level]}`}
    >
      {level} RISK
    </span>
  );
}

export function SeverityBadge({ severity }) {
  const styles = {
    Minor: "bg-cyan-400/10 text-cyan-300 border-cyan-400/30",
    Moderate: "bg-warn/10 text-warn border-warn/30",
    Major: "bg-bad/10 text-bad border-bad/30",
  };
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-mono font-medium border ${styles[severity]}`}
    >
      {severity}
    </span>
  );
}

export function FadeIn({ children, delay = 0, y = 24, className = "" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function PrimaryButton({ children, className = "", ...props }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 text-sm font-semibold text-ink bg-gradient-to-r from-cyan-300 to-blue-500 hover:opacity-90 rounded-xl px-6 py-3.5 transition-opacity shadow-glow ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

export function GhostButton({ children, className = "", ...props }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 text-sm font-semibold text-frost border border-line hover:border-cyan-400/50 hover:bg-white/[0.02] rounded-xl px-6 py-3.5 transition-colors ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
