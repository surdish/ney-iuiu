import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  ShieldAlert,
  Clock3,
  CheckCircle2,
  XCircle,
  Search,
  LayoutGrid,
  BarChart3,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";
import { GlassCard, SectionEyebrow, DecisionBadge, RiskBadge, FadeIn, AnimatedCounter } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";
import { weeklyVolume, decisionSplit, damageTypeFrequency } from "../lib/seedClaims";

const TABS = [
  { key: "overview", label: "Overview", icon: LayoutGrid },
  { key: "analytics", label: "Analytics", icon: BarChart3 },
  { key: "fraud", label: "Fraud Detection", icon: ShieldAlert },
];

export default function AdminDashboard({ initialTab = "overview" }) {
  const navigate = useNavigate();
  const { claims } = useClaims();
  const [tab, setTab] = useState(initialTab);
  const [query, setQuery] = useState("");

  const pending = claims.filter((c) => c.decision === "MANUAL REVIEW").length;
  const approved = claims.filter((c) => c.decision === "APPROVED").length;
  const rejected = claims.filter((c) => c.decision === "REJECTED").length;
  const highRisk = claims.filter((c) => c.riskLevel === "HIGH").length;

  const filteredClaims = useMemo(
    () =>
      claims.filter(
        (c) =>
          c.id.toLowerCase().includes(query.toLowerCase()) ||
          c.vehicleNumber.toLowerCase().includes(query.toLowerCase())
      ),
    [claims, query]
  );

  const flaggedClaims = claims.filter((c) => c.riskLevel !== "LOW");

  const statCards = [
    { icon: Clock3, label: "Pending Claims", value: pending, color: "text-warn" },
    { icon: CheckCircle2, label: "Approved", value: approved, color: "text-ok" },
    { icon: XCircle, label: "Rejected", value: rejected, color: "text-bad" },
    { icon: ShieldAlert, label: "Fraud Alerts", value: highRisk, color: "text-bad" },
  ];

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        <FadeIn className="mb-8">
          <SectionEyebrow>Admin</SectionEyebrow>
          <h1 className="font-display text-3xl font-semibold text-frost">Operations Dashboard</h1>
          <p className="text-sm text-mist mt-1">Monitor claim volume, decisions, and fraud signals</p>
        </FadeIn>

        <FadeIn delay={0.05} className="flex gap-2 mb-8 border-b border-line">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 -mb-px transition-colors ${
                tab === t.key ? "border-cyan-400 text-frost" : "border-transparent text-mist hover:text-frost"
              }`}
            >
              <t.icon size={15} /> {t.label}
            </button>
          ))}
        </FadeIn>

        {tab === "overview" && (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
              {statCards.map((c, i) => (
                <FadeIn key={c.label} delay={i * 0.05}>
                  <GlassCard className="p-6">
                    <c.icon size={20} className={`${c.color} mb-4`} />
                    <div className="font-display text-2xl font-semibold text-frost">
                      <AnimatedCounter value={c.value} />
                    </div>
                    <div className="text-xs text-mist mt-1">{c.label}</div>
                  </GlassCard>
                </FadeIn>
              ))}
            </div>

            <FadeIn delay={0.15}>
              <GlassCard className="p-4 mb-6">
                <div className="relative">
                  <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search claims by ID or vehicle number..."
                    className="w-full bg-white/[0.03] border border-line rounded-xl pl-10 pr-4 py-2.5 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50"
                  />
                </div>
              </GlassCard>
            </FadeIn>

            <FadeIn delay={0.2}>
              <GlassCard className="overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-xs text-mist uppercase tracking-wide border-b border-line">
                        <th className="px-6 py-4 font-medium">Claim ID</th>
                        <th className="px-6 py-4 font-medium">Vehicle</th>
                        <th className="px-6 py-4 font-medium">Date</th>
                        <th className="px-6 py-4 font-medium text-right">Cost</th>
                        <th className="px-6 py-4 font-medium">Confidence</th>
                        <th className="px-6 py-4 font-medium">Risk</th>
                        <th className="px-6 py-4 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredClaims.map((c) => (
                        <tr
                          key={c.id}
                          onClick={() => navigate(`/claims/${c.id}`)}
                          className="border-b border-line/60 last:border-0 cursor-pointer hover:bg-white/[0.02] transition-colors"
                        >
                          <td className="px-6 py-4 text-frost font-mono text-xs">{c.id}</td>
                          <td className="px-6 py-4 text-mist">{c.vehicleNumber}</td>
                          <td className="px-6 py-4 text-mist">{c.date}</td>
                          <td className="px-6 py-4 text-right font-mono text-frost">₹{c.totalCost.toLocaleString("en-IN")}</td>
                          <td className="px-6 py-4 font-mono text-cyan-300">{c.confidence}%</td>
                          <td className="px-6 py-4"><RiskBadge level={c.riskLevel} /></td>
                          <td className="px-6 py-4"><DecisionBadge decision={c.decision} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            </FadeIn>
          </>
        )}

        {tab === "analytics" && (
          <div className="grid lg:grid-cols-3 gap-6">
            <FadeIn className="lg:col-span-2">
              <GlassCard className="p-6 h-full">
                <h3 className="font-display font-semibold text-frost mb-1">Weekly Claim Volume</h3>
                <p className="text-xs text-mist mb-5">Claims processed vs. fraud alerts raised</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={weeklyVolume}>
                      <CartesianGrid stroke="#1B2947" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="day" stroke="#AEB9D4" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#AEB9D4" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ background: "#0A1224", border: "1px solid #1B2947", borderRadius: 8, fontSize: 12 }} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Line type="monotone" dataKey="claims" stroke="#3FE6F0" strokeWidth={2} dot={false} name="Claims" />
                      <Line type="monotone" dataKey="fraud" stroke="#F0596A" strokeWidth={2} dot={false} name="Fraud Alerts" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </GlassCard>
            </FadeIn>

            <FadeIn delay={0.05}>
              <GlassCard className="p-6 h-full">
                <h3 className="font-display font-semibold text-frost mb-1">Decision Split</h3>
                <p className="text-xs text-mist mb-5">Last 30 days</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={decisionSplit} dataKey="value" nameKey="name" innerRadius={55} outerRadius={80} paddingAngle={3}>
                        {decisionSplit.map((d, i) => (
                          <Cell key={i} fill={d.color} stroke="none" />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ background: "#0A1224", border: "1px solid #1B2947", borderRadius: 8, fontSize: 12 }} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </GlassCard>
            </FadeIn>

            <FadeIn delay={0.1} className="lg:col-span-3">
              <GlassCard className="p-6">
                <h3 className="font-display font-semibold text-frost mb-1">Damage Type Frequency</h3>
                <p className="text-xs text-mist mb-5">Most common detected damage classes</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={damageTypeFrequency}>
                      <CartesianGrid stroke="#1B2947" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="type" stroke="#AEB9D4" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#AEB9D4" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ background: "#0A1224", border: "1px solid #1B2947", borderRadius: 8, fontSize: 12 }} />
                      <Bar dataKey="count" fill="#3B6FE0" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </GlassCard>
            </FadeIn>
          </div>
        )}

        {tab === "fraud" && (
          <div>
            <div className="grid sm:grid-cols-3 gap-5 mb-6">
              <FadeIn>
                <GlassCard className="p-6">
                  <div className="font-display text-2xl font-semibold text-bad">{highRisk}</div>
                  <div className="text-xs text-mist mt-1">High Risk Claims</div>
                </GlassCard>
              </FadeIn>
              <FadeIn delay={0.05}>
                <GlassCard className="p-6">
                  <div className="font-display text-2xl font-semibold text-warn">
                    {claims.filter((c) => c.riskLevel === "MEDIUM").length}
                  </div>
                  <div className="text-xs text-mist mt-1">Medium Risk Claims</div>
                </GlassCard>
              </FadeIn>
              <FadeIn delay={0.1}>
                <GlassCard className="p-6">
                  <div className="font-display text-2xl font-semibold text-ok">
                    {((claims.filter((c) => c.riskLevel === "LOW").length / claims.length) * 100).toFixed(0)}%
                  </div>
                  <div className="text-xs text-mist mt-1">Clean Claim Rate</div>
                </GlassCard>
              </FadeIn>
            </div>

            <FadeIn delay={0.15}>
              <GlassCard className="overflow-hidden">
                <div className="px-6 py-4 border-b border-line">
                  <h3 className="font-display font-semibold text-frost">Flagged Claims</h3>
                  <p className="text-xs text-mist mt-1">Claims requiring manual fraud review</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-xs text-mist uppercase tracking-wide border-b border-line">
                        <th className="px-6 py-4 font-medium">Claim ID</th>
                        <th className="px-6 py-4 font-medium">Vehicle</th>
                        <th className="px-6 py-4 font-medium">Cost</th>
                        <th className="px-6 py-4 font-medium">Confidence</th>
                        <th className="px-6 py-4 font-medium">Risk Level</th>
                        <th className="px-6 py-4 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {flaggedClaims.map((c) => (
                        <tr
                          key={c.id}
                          onClick={() => navigate(`/claims/${c.id}`)}
                          className="border-b border-line/60 last:border-0 cursor-pointer hover:bg-white/[0.02] transition-colors"
                        >
                          <td className="px-6 py-4 text-frost font-mono text-xs">{c.id}</td>
                          <td className="px-6 py-4 text-mist">{c.vehicleNumber}</td>
                          <td className="px-6 py-4 font-mono text-frost">₹{c.totalCost.toLocaleString("en-IN")}</td>
                          <td className="px-6 py-4 font-mono text-cyan-300">{c.confidence}%</td>
                          <td className="px-6 py-4"><RiskBadge level={c.riskLevel} /></td>
                          <td className="px-6 py-4"><DecisionBadge decision={c.decision} /></td>
                        </tr>
                      ))}
                      {flaggedClaims.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-6 py-10 text-center text-mist text-sm">
                            No flagged claims right now.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            </FadeIn>
          </div>
        )}
      </div>
    </div>
  );
}
