import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, FileDown } from "lucide-react";
import { GlassCard, SectionEyebrow, DecisionBadge, RiskBadge, GhostButton, FadeIn } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";

export default function ClaimDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { claims } = useClaims();
  const claim = claims.find((c) => c.id === id);

  if (!claim) {
    return (
      <div className="min-h-screen pt-40 pb-24 px-6 text-center">
        <h1 className="font-display text-2xl text-frost mb-4">Claim not found</h1>
        <GhostButton onClick={() => navigate("/claims/history")}>
          <ArrowLeft size={16} /> Back to history
        </GhostButton>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-4xl mx-auto">
        <FadeIn>
          <button
            onClick={() => navigate("/claims/history")}
            className="flex items-center gap-2 text-sm text-mist hover:text-frost mb-8"
          >
            <ArrowLeft size={16} /> Back to history
          </button>
        </FadeIn>

        <FadeIn delay={0.05} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <SectionEyebrow>Claim Details</SectionEyebrow>
            <h1 className="font-display text-3xl font-semibold text-frost">#{claim.id}</h1>
          </div>
          <GhostButton onClick={() => window.print()}>
            <FileDown size={16} /> Download PDF Report
          </GhostButton>
        </FadeIn>

        <div className="grid sm:grid-cols-2 gap-6 mb-6">
          <FadeIn delay={0.1}>
            <GlassCard className="p-6">
              <h3 className="text-xs font-mono uppercase tracking-wide text-mist mb-4">Decision</h3>
              <DecisionBadge decision={claim.decision} />
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Confidence</div>
                  <div className="font-mono text-frost">{claim.confidence}%</div>
                </div>
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Fraud Risk</div>
                  <div className="mt-1"><RiskBadge level={claim.riskLevel} /></div>
                </div>
              </div>
            </GlassCard>
          </FadeIn>

          <FadeIn delay={0.15}>
            <GlassCard className="p-6">
              <h3 className="text-xs font-mono uppercase tracking-wide text-mist mb-4">Claim Info</h3>
              <dl className="space-y-3 text-sm">
                <div className="flex justify-between"><dt className="text-mist">Vehicle</dt><dd className="text-frost font-medium">{claim.vehicleNumber}</dd></div>
                <div className="flex justify-between"><dt className="text-mist">Date Filed</dt><dd className="text-frost font-medium">{claim.date}</dd></div>
                <div className="flex justify-between"><dt className="text-mist">Est. Cost</dt><dd className="text-frost font-medium font-mono">₹{claim.totalCost.toLocaleString("en-IN")}</dd></div>
              </dl>
            </GlassCard>
          </FadeIn>
        </div>

        <FadeIn delay={0.2}>
          <GlassCard className="p-6">
            <h3 className="text-xs font-mono uppercase tracking-wide text-mist mb-4">Detected Damage</h3>
            <div className="flex flex-wrap gap-2">
              {claim.damageTypes.map((d, i) => (
                <span key={i} className="px-3 py-1.5 rounded-full text-xs font-medium bg-white/[0.03] border border-line text-frost">
                  {d}
                </span>
              ))}
            </div>
          </GlassCard>
        </FadeIn>
      </div>
    </div>
  );
}
