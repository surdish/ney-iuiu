import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Search, SlidersHorizontal } from "lucide-react";
import { GlassCard, SectionEyebrow, DecisionBadge, FadeIn } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";

const FILTERS = ["All", "APPROVED", "MANUAL REVIEW", "REJECTED"];

export default function ClaimHistory() {
  const navigate = useNavigate();
  const { claims } = useClaims();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [sort, setSort] = useState("newest");

  const filtered = useMemo(() => {
    let list = claims.filter((c) => {
      const matchesQuery =
        c.id.toLowerCase().includes(query.toLowerCase()) ||
        c.vehicleNumber.toLowerCase().includes(query.toLowerCase());
      const matchesFilter = filter === "All" || c.decision === filter;
      return matchesQuery && matchesFilter;
    });
    list = [...list].sort((a, b) => {
      if (sort === "newest") return b.date.localeCompare(a.date);
      if (sort === "oldest") return a.date.localeCompare(b.date);
      if (sort === "cost-high") return b.totalCost - a.totalCost;
      if (sort === "cost-low") return a.totalCost - b.totalCost;
      return 0;
    });
    return list;
  }, [claims, query, filter, sort]);

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-6xl mx-auto">
        <FadeIn className="mb-8">
          <SectionEyebrow>Claims</SectionEyebrow>
          <h1 className="font-display text-3xl font-semibold text-frost">Claim History</h1>
          <p className="text-sm text-mist mt-1">{claims.length} total claims on record</p>
        </FadeIn>

        <FadeIn delay={0.05}>
          <GlassCard className="p-4 mb-6 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by claim ID or vehicle number..."
                className="w-full bg-white/[0.03] border border-line rounded-xl pl-10 pr-4 py-2.5 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {FILTERS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`shrink-0 px-3.5 py-2 rounded-lg text-xs font-medium border transition-colors ${
                    filter === f
                      ? "border-cyan-400/50 bg-cyan-400/10 text-cyan-300"
                      : "border-line text-mist hover:text-frost"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="bg-white/[0.03] border border-line rounded-xl px-3 py-2.5 text-xs text-mist focus:outline-none focus:border-cyan-400/50"
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="cost-high">Cost: High to low</option>
              <option value="cost-low">Cost: Low to high</option>
            </select>
          </GlassCard>
        </FadeIn>

        <FadeIn delay={0.1}>
          <GlassCard className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-mist uppercase tracking-wide border-b border-line">
                    <th className="px-6 py-4 font-medium">Claim ID</th>
                    <th className="px-6 py-4 font-medium">Vehicle</th>
                    <th className="px-6 py-4 font-medium">Damage</th>
                    <th className="px-6 py-4 font-medium">Date</th>
                    <th className="px-6 py-4 font-medium text-right">Cost</th>
                    <th className="px-6 py-4 font-medium">Confidence</th>
                    <th className="px-6 py-4 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((c) => (
                    <tr
                      key={c.id}
                      onClick={() => navigate(`/claims/${c.id}`)}
                      className="border-b border-line/60 last:border-0 cursor-pointer hover:bg-white/[0.02] transition-colors"
                    >
                      <td className="px-6 py-4 text-frost font-mono text-xs">{c.id}</td>
                      <td className="px-6 py-4 text-mist">{c.vehicleNumber}</td>
                      <td className="px-6 py-4 text-mist text-xs">{c.damageTypes[0]}{c.damageTypes.length > 1 ? ` +${c.damageTypes.length - 1}` : ""}</td>
                      <td className="px-6 py-4 text-mist">{c.date}</td>
                      <td className="px-6 py-4 text-right font-mono text-frost">₹{c.totalCost.toLocaleString("en-IN")}</td>
                      <td className="px-6 py-4 font-mono text-cyan-300">{c.confidence}%</td>
                      <td className="px-6 py-4"><DecisionBadge decision={c.decision} /></td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-6 py-10 text-center text-mist text-sm">
                        No claims match your search.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </FadeIn>
      </div>
    </div>
  );
}
