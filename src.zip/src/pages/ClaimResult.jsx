import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { analyzeClaimWithClaude } from "../lib/claudeApi";
import {
  FileDown,
  Copy,
  AlertTriangle,
  Fingerprint,
  MapPinOff,
  Clock,
  ImageOff,
  CheckCircle2,
  XCircle,
  Sparkles,
  MessageSquare,
  WifiOff,
} from "lucide-react";
import {
  GlassCard,
  SectionEyebrow,
  DecisionBadge,
  RiskBadge,
  SeverityBadge,
  PrimaryButton,
  GhostButton,
  FadeIn,
} from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";

export default function ClaimResult() {
  const navigate = useNavigate();
  const { lastResult } = useClaims();
  const [activeImg, setActiveImg] = useState(0);

  // Claude AI commentary state
  const [claudeState, setClaudeState] = useState({
    status: "idle", // "idle" | "loading" | "success" | "error"
    data: null,
    error: null,
  });

  if (!lastResult) {
    return (
      <div className="min-h-screen pt-40 pb-24 px-6 text-center">
        <h1 className="font-display text-2xl text-frost mb-4">No claim result yet</h1>
        <p className="text-mist mb-8">Start a new claim to see an AI assessment here.</p>
        <PrimaryButton onClick={() => navigate("/claim/new")}>Start a Claim</PrimaryButton>
      </div>
    );
  }

  const { analyses, fraud, recommendation, claimId, previews, form, date } = lastResult;
  const currentAnalysis = analyses[activeImg];
  const allDamages = analyses.flatMap((a) => a.damages);

  // Trigger Claude analysis once the result is available
  useEffect(() => {
    if (!lastResult) return;

    setClaudeState({ status: "loading", data: null, error: null });

    const payload = {
      damages: allDamages.map((d) => ({
        type: d.type,
        part: d.part,
        severity: d.severity,
        confidence: d.confidence,
        estCost: d.estCost,
      })),
      totalCost: recommendation.totalCost,
      fraudRiskLevel: fraud.riskLevel,
      fraudRiskScore: fraud.riskScore,
      fraudFlags: fraud.metadataFlags || [],
      decisionFromEngine: recommendation.decision,
      avgConfidence: recommendation.avgConfidence,
      vehicleNumber: form?.vehicleNumber || "",
      description: form?.description || "",
    };

    analyzeClaimWithClaude(payload).then(({ data, error }) => {
      if (error) {
        setClaudeState({ status: "error", data: null, error });
      } else {
        setClaudeState({ status: "success", data, error: null });
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [claimId]);

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-6xl mx-auto">
        <FadeIn className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <SectionEyebrow>Claim Result</SectionEyebrow>
            <h1 className="font-display text-3xl font-semibold text-frost">
              Claim #{claimId}
            </h1>
            <p className="text-sm text-mist mt-1">
              Submitted {date} {form?.vehicleNumber && `· ${form.vehicleNumber}`}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <GhostButton onClick={() => window.print()}>
              <FileDown size={16} /> Download PDF Report
            </GhostButton>
          </div>
        </FadeIn>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* LEFT: image with bounding boxes */}
          <div className="lg:col-span-3 space-y-4">
            <FadeIn>
              <GlassCard className="p-3">
                <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-panel2">
                  {previews[activeImg] && (
                    <img
                      src={previews[activeImg]}
                      alt={`Claim evidence ${activeImg + 1}`}
                      className="w-full h-full object-cover"
                    />
                  )}
                  {currentAnalysis?.damages.map((d) => (
                    <div
                      key={d.id}
                      className="absolute border-2 border-cyan-300 rounded-md"
                      style={{
                        left: `${d.box.x}%`,
                        top: `${d.box.y}%`,
                        width: `${d.box.w}%`,
                        height: `${d.box.h}%`,
                      }}
                    >
                      <span className="absolute -top-6 left-0 whitespace-nowrap text-[10px] font-mono bg-cyan-300 text-ink px-1.5 py-0.5 rounded">
                        {d.type} {d.confidence}%
                      </span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </FadeIn>

            {previews.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1">
                {previews.map((src, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      activeImg === i ? "border-cyan-400" : "border-line"
                    }`}
                  >
                    <img src={src} alt={`thumb ${i}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Detected damages table */}
            <FadeIn delay={0.05}>
              <GlassCard className="p-6">
                <h3 className="font-display font-semibold text-frost mb-4">
                  Detected Damage &amp; Repair Cost
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-xs text-mist uppercase tracking-wide border-b border-line">
                        <th className="pb-3 font-medium">Damage Type</th>
                        <th className="pb-3 font-medium">Part</th>
                        <th className="pb-3 font-medium">Severity</th>
                        <th className="pb-3 font-medium">Confidence</th>
                        <th className="pb-3 font-medium text-right">Est. Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allDamages.map((d) => (
                        <tr key={d.id} className="border-b border-line/60 last:border-0">
                          <td className="py-3.5 text-frost font-medium">{d.type}</td>
                          <td className="py-3.5 text-mist">{d.part}</td>
                          <td className="py-3.5"><SeverityBadge severity={d.severity} /></td>
                          <td className="py-3.5 font-mono text-cyan-300">{d.confidence}%</td>
                          <td className="py-3.5 text-right font-mono text-frost">
                            ₹{d.estCost.toLocaleString("en-IN")}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={4} className="pt-4 text-frost font-semibold">Total Estimated Cost</td>
                        <td className="pt-4 text-right font-mono font-semibold text-cyan-300">
                          ₹{recommendation.totalCost.toLocaleString("en-IN")}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </GlassCard>
            </FadeIn>
          </div>

          {/* RIGHT: summary + fraud + recommendation */}
          <div className="lg:col-span-2 space-y-6">
            <FadeIn delay={0.1}>
              <GlassCard className="p-6">
                <div className="flex items-center justify-between mb-5">
                  <span className="text-xs font-mono text-mist">RECOMMENDATION</span>
                  <DecisionBadge decision={recommendation.decision} />
                </div>
                <div className="grid grid-cols-2 gap-3 mb-5">
                  <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                    <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Overall Confidence</div>
                    <div className="font-mono text-frost text-lg">{recommendation.overallConfidence}%</div>
                  </div>
                  <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                    <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Fraud Risk</div>
                    <div className="mt-1"><RiskBadge level={fraud.riskLevel} /></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wide text-mist">Why this decision</h4>
                  {recommendation.reasons.map((r, i) => (
                    <div key={i} className="flex gap-2.5 text-sm text-mist leading-relaxed">
                      <span className="text-cyan-300 mt-0.5">›</span>
                      {r}
                    </div>
                  ))}
                </div>
              </GlassCard>
            </FadeIn>

            <FadeIn delay={0.15}>
              <GlassCard className="p-6">
                <h3 className="font-display font-semibold text-frost mb-5 flex items-center gap-2">
                  <AlertTriangle size={16} className="text-cyan-300" /> Fraud Analysis
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-mist flex items-center gap-2">
                      <Copy size={14} /> Duplicate Image Status
                    </span>
                    {fraud.hasDuplicates ? (
                      <span className="flex items-center gap-1.5 text-xs font-mono text-bad">
                        <XCircle size={13} /> Duplicates Found
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-xs font-mono text-ok">
                        <CheckCircle2 size={13} /> Unique
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-mist flex items-center gap-2">
                      <Fingerprint size={14} /> EXIF Metadata
                    </span>
                    <span className={`text-xs font-mono ${fraud.metadataFlags.length ? "text-warn" : "text-ok"}`}>
                      {fraud.metadataFlags.length} flag(s)
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-mist flex items-center gap-2">
                      <AlertTriangle size={14} /> Cost Anomaly Check
                    </span>
                    <span className={`text-xs font-mono ${fraud.costAnomalyFlag ? "text-warn" : "text-ok"}`}>
                      {fraud.costAnomalyFlag ? "Deviation flagged" : "Within range"}
                    </span>
                  </div>

                  {fraud.metadataFlags.length > 0 && (
                    <div className="pt-3 border-t border-line space-y-2">
                      {fraud.metadataFlags.map((f, i) => (
                        <div key={i} className="flex gap-2 text-xs text-mist">
                          {f.includes("GPS") ? <MapPinOff size={13} className="text-warn mt-0.5 shrink-0" /> :
                           f.includes("timestamp") ? <Clock size={13} className="text-warn mt-0.5 shrink-0" /> :
                           <ImageOff size={13} className="text-warn mt-0.5 shrink-0" />}
                          {f}
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="pt-3 border-t border-line">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-mist">Fraud Risk Score</span>
                      <span className="text-xs font-mono text-frost">{fraud.riskScore}/100</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          fraud.riskLevel === "HIGH" ? "bg-bad" : fraud.riskLevel === "MEDIUM" ? "bg-warn" : "bg-ok"
                        }`}
                        style={{ width: `${fraud.riskScore}%` }}
                      />
                    </div>
                  </div>
                </div>
              </GlassCard>
            </FadeIn>

            <FadeIn delay={0.2}>
              <GlassCard className="p-6">
                <h3 className="font-display font-semibold text-frost mb-4">Claim Details</h3>
                <dl className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-mist">Vehicle Number</dt>
                    <dd className="text-frost font-medium">{form?.vehicleNumber || "—"}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-mist">Insurance Number</dt>
                    <dd className="text-frost font-medium">{form?.insuranceNumber || "—"}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-mist">Images Submitted</dt>
                    <dd className="text-frost font-medium">{previews.length}</dd>
                  </div>
                </dl>
                {form?.description && (
                  <p className="text-xs text-mist mt-4 pt-4 border-t border-line leading-relaxed">
                    {form.description}
                  </p>
                )}
              </GlassCard>
            </FadeIn>

            {/* ── AI COMMENTARY ─────────────────────────────── */}
            <FadeIn delay={0.25}>
              <GlassCard className="p-6">
                <h3 className="font-display font-semibold text-frost mb-4 flex items-center gap-2">
                  <Sparkles size={16} className="text-cyan-300" /> Claude AI Commentary
                </h3>

                {/* Loading skeleton */}
                {claudeState.status === "loading" && (
                  <div className="space-y-3 animate-pulse">
                    <div className="h-3 bg-white/[0.06] rounded-full w-full" />
                    <div className="h-3 bg-white/[0.06] rounded-full w-5/6" />
                    <div className="h-3 bg-white/[0.06] rounded-full w-4/6" />
                    <div className="mt-4 h-3 bg-white/[0.04] rounded-full w-full" />
                    <div className="h-3 bg-white/[0.04] rounded-full w-3/4" />
                    <p className="text-xs text-mist/50 mt-2 text-center">Consulting Claude…</p>
                  </div>
                )}

                {/* Error state */}
                {claudeState.status === "error" && (
                  <div className="rounded-xl bg-bad/5 border border-bad/20 p-4">
                    <div className="flex items-start gap-2.5 mb-2">
                      <WifiOff size={15} className="text-bad shrink-0 mt-0.5" />
                      <p className="text-sm font-medium text-bad">AI Commentary Unavailable</p>
                    </div>
                    <p className="text-xs text-mist leading-relaxed">{claudeState.error}</p>
                    <button
                      onClick={() => {
                        setClaudeState({ status: "loading", data: null, error: null });
                        analyzeClaimWithClaude({
                          damages: allDamages,
                          totalCost: recommendation.totalCost,
                          fraudRiskLevel: fraud.riskLevel,
                          fraudRiskScore: fraud.riskScore,
                          fraudFlags: fraud.metadataFlags || [],
                          decisionFromEngine: recommendation.decision,
                          avgConfidence: recommendation.avgConfidence,
                          vehicleNumber: form?.vehicleNumber || "",
                          description: form?.description || "",
                        }).then(({ data, error }) =>
                          setClaudeState(
                            error
                              ? { status: "error", data: null, error }
                              : { status: "success", data, error: null }
                          )
                        );
                      }}
                      className="mt-3 text-xs text-cyan-300 hover:text-cyan-200 transition-colors"
                    >
                      Retry →
                    </button>
                  </div>
                )}

                {/* Success state */}
                {claudeState.status === "success" && claudeState.data && (
                  <div className="space-y-4">
                    {/* Commentary */}
                    <p className="text-sm text-mist leading-relaxed">
                      {claudeState.data.commentary}
                    </p>

                    {/* Key Findings */}
                    {claudeState.data.keyFindings?.length > 0 && (
                      <div>
                        <p className="text-[10px] font-mono uppercase tracking-wider text-cyan-300 mb-2">Key Findings</p>
                        <ul className="space-y-1.5">
                          {claudeState.data.keyFindings.map((f, i) => (
                            <li key={i} className="flex gap-2 text-xs text-mist">
                              <span className="text-cyan-300 shrink-0">›</span>
                              {f}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Recommendation */}
                    {claudeState.data.recommendation && (
                      <div className="rounded-lg bg-cyan-400/5 border border-cyan-400/20 p-3">
                        <p className="text-[10px] font-mono uppercase tracking-wider text-cyan-300 mb-1">Recommendation</p>
                        <p className="text-xs text-frost leading-relaxed">{claudeState.data.recommendation}</p>
                      </div>
                    )}

                    {/* Confidence assessment */}
                    {claudeState.data.confidenceAssessment && (
                      <p className="text-[11px] text-mist/60 italic leading-relaxed border-t border-line pt-3">
                        <MessageSquare size={11} className="inline mr-1 mb-0.5" />
                        {claudeState.data.confidenceAssessment}
                      </p>
                    )}
                  </div>
                )}
              </GlassCard>
            </FadeIn>

            <Link
              to="/claims/history"
              className="block text-center text-sm text-cyan-300 hover:text-cyan-200 font-medium"
            >
              View all claims →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
