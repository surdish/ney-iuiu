import { useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { UploadCloud, X, Image as ImageIcon, Loader2, CheckCircle2 } from "lucide-react";
import { GlassCard, PrimaryButton, SectionEyebrow, FadeIn } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";
import { runFullAnalysis } from "../lib/aiEngine";

const PROGRESS_STEPS = [
  "Uploading images",
  "Running AI quality check",
  "Detecting damage regions",
  "Estimating repair cost",
  "Scanning for fraud signals",
  "Generating recommendation",
];

export default function ClaimUpload() {
  const navigate = useNavigate();
  const { addClaim, setLastResult } = useClaims();
  const [files, setFiles] = useState([]);
  const [dragActive, setDragActive] = useState(false);
  const [form, setForm] = useState({
    vehicleNumber: "",
    insuranceNumber: "",
    description: "",
  });
  const [processing, setProcessing] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const inputRef = useRef(null);

  const onFiles = useCallback((fileList) => {
    const arr = Array.from(fileList).filter((f) => f.type.startsWith("image/"));
    setFiles((prev) => [...prev, ...arr].slice(0, 10));
  }, []);

  function handleDrop(e) {
    e.preventDefault();
    setDragActive(false);
    onFiles(e.dataTransfer.files);
  }

  function removeFile(idx) {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (files.length === 0) return;
    setProcessing(true);
    setStepIndex(0);

    let step = 0;
    const interval = setInterval(() => {
      step += 1;
      setStepIndex(step);
      if (step >= PROGRESS_STEPS.length) {
        clearInterval(interval);
        const result = runFullAnalysis(files);
        const previews = files.map((f) => URL.createObjectURL(f));
        const claimId = `CV-${10246 + Math.floor(Math.random() * 900)}`;

        const fullResult = {
          ...result,
          claimId,
          previews,
          form,
          fileNames: files.map((f) => f.name),
          date: new Date().toISOString().slice(0, 10),
        };

        setLastResult(fullResult);
        addClaim({
          id: claimId,
          vehicleNumber: form.vehicleNumber || "Not provided",
          date: fullResult.date,
          damageTypes: result.analyses.flatMap((a) => a.damages.map((d) => d.type)),
          totalCost: result.recommendation.totalCost,
          confidence: Math.round(result.recommendation.avgConfidence),
          decision: result.recommendation.decision,
          riskLevel: result.fraud.riskLevel,
        });

        setTimeout(() => navigate("/claim/result"), 500);
      }
    }, 550);
  }

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 relative">
      <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
      <div className="max-w-3xl mx-auto relative">
        <FadeIn className="text-center mb-12">
          <SectionEyebrow><span className="mx-auto">New Claim</span></SectionEyebrow>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
            Upload vehicle images
          </h1>
          <p className="text-mist mt-3">
            Add photos from multiple angles for the most accurate assessment.
          </p>
        </FadeIn>

        {!processing ? (
          <FadeIn delay={0.1}>
            <form onSubmit={handleSubmit} className="space-y-6">
              <GlassCard
                className={`p-10 border-2 border-dashed transition-colors cursor-pointer ${
                  dragActive ? "border-cyan-400/60 bg-cyan-400/5" : "border-line"
                }`}
                onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                onClick={() => inputRef.current?.click()}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  hidden
                  onChange={(e) => onFiles(e.target.files)}
                />
                <div className="text-center">
                  <UploadCloud size={36} className="text-cyan-300 mx-auto mb-4" />
                  <p className="text-frost font-medium">Drag and drop images here</p>
                  <p className="text-sm text-mist mt-1">or click to browse — up to 10 images</p>
                </div>

                {files.length > 0 && (
                  <div className="mt-8 grid grid-cols-3 sm:grid-cols-4 gap-3" onClick={(e) => e.stopPropagation()}>
                    {files.map((f, i) => (
                      <div key={i} className="relative group aspect-square rounded-xl overflow-hidden border border-line">
                        <img
                          src={URL.createObjectURL(f)}
                          alt={f.name}
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => removeFile(i)}
                          className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-ink/80 flex items-center justify-center text-frost hover:bg-bad/80 transition-colors"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </GlassCard>

              <GlassCard className="p-8 space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="text-xs font-medium text-mist mb-2 block">Vehicle Number</label>
                    <input
                      type="text"
                      placeholder="TN 22 AB 4471"
                      value={form.vehicleNumber}
                      onChange={(e) => setForm({ ...form, vehicleNumber: e.target.value })}
                      className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-mist mb-2 block">Insurance Number</label>
                    <input
                      type="text"
                      placeholder="INS-8842-2026"
                      value={form.insuranceNumber}
                      onChange={(e) => setForm({ ...form, insuranceNumber: e.target.value })}
                      className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-mist mb-2 block">Incident Description</label>
                  <textarea
                    rows={4}
                    placeholder="Describe how the damage occurred..."
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full bg-white/[0.03] border border-line rounded-xl px-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors resize-none"
                  />
                </div>
              </GlassCard>

              <PrimaryButton type="submit" className="w-full" disabled={files.length === 0}>
                Submit Claim
              </PrimaryButton>
              {files.length === 0 && (
                <p className="text-center text-xs text-mist">Add at least one image to continue</p>
              )}
            </form>
          </FadeIn>
        ) : (
          <FadeIn>
            <GlassCard className="p-10">
              <div className="flex flex-col items-center text-center mb-8">
                <Loader2 size={32} className="text-cyan-300 animate-spin mb-4" />
                <h3 className="font-display text-xl font-semibold text-frost">
                  Analyzing your claim
                </h3>
                <p className="text-sm text-mist mt-1">This usually takes a few seconds</p>
              </div>
              <div className="space-y-3">
                {PROGRESS_STEPS.map((step, i) => (
                  <div
                    key={step}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-colors ${
                      i < stepIndex
                        ? "border-ok/30 bg-ok/5"
                        : i === stepIndex
                        ? "border-cyan-400/40 bg-cyan-400/5"
                        : "border-line bg-white/[0.01]"
                    }`}
                  >
                    {i < stepIndex ? (
                      <CheckCircle2 size={16} className="text-ok shrink-0" />
                    ) : i === stepIndex ? (
                      <Loader2 size={16} className="text-cyan-300 animate-spin shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-line shrink-0" />
                    )}
                    <span
                      className={`text-sm ${
                        i <= stepIndex ? "text-frost" : "text-mist/60"
                      }`}
                    >
                      {step}
                    </span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </FadeIn>
        )}
      </div>
    </div>
  );
}
