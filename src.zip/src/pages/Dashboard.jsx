import { Link, useNavigate } from "react-router-dom";
import { PlusCircle, FileText, Clock3, ShieldCheck, TrendingUp } from "lucide-react";
import { GlassCard, SectionEyebrow, DecisionBadge, PrimaryButton, FadeIn, AnimatedCounter } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";
import { AreaChart, Area, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import { weeklyVolume } from "../lib/seedClaims";

export default function Dashboard() {
  const navigate = useNavigate();
  const { claims } = useClaims();

  const approved = claims.filter((c) => c.decision === "APPROVED").length;
  const review = claims.filter((c) => c.decision === "MANUAL REVIEW").length;
  const avgConfidence = Math.round(claims.reduce((s, c) => s + c.confidence, 0) / claims.length);

  const cards = [
    { icon: FileText, label: "Total Claims", value: claims.length, suffix: "" },
    { icon: ShieldCheck, label: "Approved", value: approved, suffix: "" },
    { icon: Clock3, label: "In Review", value: review, suffix: "" },
    { icon: TrendingUp, label: "Avg Confidence", value: avgConfidence, suffix: "%" },
  ];

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        <FadeIn className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <SectionEyebrow>Dashboard</SectionEyebrow>
            <h1 className="font-display text-3xl font-semibold text-frost">Welcome back</h1>
            <p className="text-sm text-mist mt-1">Here&apos;s what&apos;s happening with your claims</p>
          </div>
          <PrimaryButton onClick={() => navigate("/claim/new")}>
            <PlusCircle size={16} /> New Claim
          </PrimaryButton>
        </FadeIn>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {cards.map((c, i) => (
            <FadeIn key={c.label} delay={i * 0.05}>
              <GlassCard className="p-6">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-700/60 to-cyan-400/20 border border-cyan-400/20 flex items-center justify-center mb-4">
                  <c.icon size={18} className="text-cyan-300" />
                </div>
                <div className="font-display text-2xl font-semibold text-frost">
                  <AnimatedCounter value={c.value} suffix={c.suffix} />
                </div>
                <div className="text-xs text-mist mt-1">{c.label}</div>
              </GlassCard>
            </FadeIn>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <FadeIn delay={0.1} className="lg:col-span-2">
            <GlassCard className="p-6 h-full">
              <h3 className="font-display font-semibold text-frost mb-1">Claims Processed</h3>
              <p className="text-xs text-mist mb-4">Last 7 days</p>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={weeklyVolume}>
                    <defs>
                      <linearGradient id="claimsGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3FE6F0" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#3FE6F0" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="day" stroke="#AEB9D4" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{ background: "#0A1224", border: "1px solid #1B2947", borderRadius: 8, fontSize: 12 }}
                      labelStyle={{ color: "#F4F7FD" }}
                    />
                    <Area type="monotone" dataKey="claims" stroke="#3FE6F0" strokeWidth={2} fill="url(#claimsGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </GlassCard>
          </FadeIn>

          <FadeIn delay={0.15}>
            <GlassCard className="p-6 h-full">
              <h3 className="font-display font-semibold text-frost mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link to="/claim/new" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.02] border border-line hover:border-cyan-400/40 transition-colors text-sm text-frost">
                  <PlusCircle size={16} className="text-cyan-300" /> Start a new claim
                </Link>
                <Link to="/claims/history" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.02] border border-line hover:border-cyan-400/40 transition-colors text-sm text-frost">
                  <FileText size={16} className="text-cyan-300" /> View claim history
                </Link>
                <Link to="/admin" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.02] border border-line hover:border-cyan-400/40 transition-colors text-sm text-frost">
                  <ShieldCheck size={16} className="text-cyan-300" /> Open admin dashboard
                </Link>
              </div>
            </GlassCard>
          </FadeIn>
        </div>

        <FadeIn delay={0.2} className="mt-6">
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display font-semibold text-frost">Recent Claims</h3>
              <Link to="/claims/history" className="text-xs text-cyan-300 hover:text-cyan-200 font-medium">
                View all
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-mist uppercase tracking-wide border-b border-line">
                    <th className="pb-3 font-medium">Claim ID</th>
                    <th className="pb-3 font-medium">Vehicle</th>
                    <th className="pb-3 font-medium">Date</th>
                    <th className="pb-3 font-medium text-right">Cost</th>
                    <th className="pb-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {claims.slice(0, 5).map((c) => (
                    <tr
                      key={c.id}
                      className="border-b border-line/60 last:border-0 cursor-pointer hover:bg-white/[0.02]"
                      onClick={() => navigate(`/claims/${c.id}`)}
                    >
                      <td className="py-3.5 text-frost font-mono text-xs">{c.id}</td>
                      <td className="py-3.5 text-mist">{c.vehicleNumber}</td>
                      <td className="py-3.5 text-mist">{c.date}</td>
                      <td className="py-3.5 text-right font-mono text-frost">₹{c.totalCost.toLocaleString("en-IN")}</td>
                      <td className="py-3.5"><DecisionBadge decision={c.decision} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </FadeIn>
      </div>
    </div>
  );
}
