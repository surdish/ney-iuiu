import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ScanEye,
  Wallet,
  ShieldAlert,
  BrainCircuit,
  ClipboardCheck,
  LayoutDashboard,
  UploadCloud,
  ScanSearch,
  Ruler,
  FileSearch2,
  Sparkles,
  FileDown,
  Play,
  ArrowRight,
  Building2,
  Landmark,
  Car,
  Warehouse,
  Wrench,
  Check,
  ChevronDown,
  X,
} from "lucide-react";
import {
  GlassCard,
  SectionEyebrow,
  AnimatedCounter,
  FadeIn,
  PrimaryButton,
  GhostButton,
  DecisionBadge,
  RiskBadge,
  SeverityBadge,
} from "../components/ui";
import ScanVisual from "../components/ScanVisual";
import { useClaims } from "../lib/ClaimsContext";

const capabilities = [
  { title: "Computer Vision", desc: "Automated damage localization & classification" },
  { title: "Valuation Engine", desc: "Standardized parts & labor costing lookup" },
  { title: "Fraud Guard", desc: "Duplicate image & EXIF metadata anomaly checks" },
  { title: "Audit Trail", desc: "Explainable recommendations with scoring log" },
];

const trustedBy = [
  { icon: Landmark, label: "Government" },
  { icon: Building2, label: "Insurance" },
  { icon: Car, label: "Automobile" },
  { icon: Warehouse, label: "Dealership" },
  { icon: Wrench, label: "Repair Centers" },
];

const features = [
  {
    icon: ScanSearch,
    title: "AI Damage Detection",
    desc: "Detect dents, scratches, cracks, broken glass, and bumper damage using computer vision trained on labeled repair data.",
  },
  {
    icon: Wallet,
    title: "Repair Cost Estimation",
    desc: "Generate repair cost ranges from standardized parts and labor pricing tables, matched to detected damage severity.",
  },
  {
    icon: ShieldAlert,
    title: "Fraud Detection",
    desc: "Duplicate image detection, EXIF metadata analysis, and statistical anomaly checks flag suspicious claims automatically.",
  },
  {
    icon: BrainCircuit,
    title: "Explainable AI",
    desc: "Every recommendation ships with a human-readable report, a confidence score, and the reasoning behind the decision.",
  },
  {
    icon: ClipboardCheck,
    title: "Claim Recommendation",
    desc: "Each claim resolves to a clear outcome — Approve, Manual Review, or Reject — with the evidence that led there.",
  },
  {
    icon: LayoutDashboard,
    title: "Analytics Dashboard",
    desc: "Track claim history, fraud alerts, and processing analytics from a single operations dashboard.",
  },
];

const steps = [
  { icon: UploadCloud, title: "Upload Vehicle Images", desc: "Add photos of the damaged vehicle from any angle." },
  { icon: FileSearch2, title: "AI Quality Check", desc: "Images are checked for clarity, angle, and completeness." },
  { icon: ScanSearch, title: "Damage Detection", desc: "Computer vision localizes and classifies every damage region." },
  { icon: Ruler, title: "Repair Cost Estimation", desc: "Standardized pricing tables generate a cost range per part." },
  { icon: ShieldAlert, title: "Fraud Detection", desc: "Duplicate, metadata, and anomaly checks run in parallel." },
  { icon: BrainCircuit, title: "AI Recommendation", desc: "An explainable decision is generated with a confidence score." },
  { icon: FileDown, title: "Download Claim Report", desc: "A complete, shareable report is ready in seconds." },
];

const pricingPlans = [
  {
    id: "plan_starter",
    name: "Starter",
    desc: "For small workshops and independent assessors.",
    monthlyPrice: 0,
    yearlyPrice: 0,
    features: [
      "Up to 15 claim assessments/mo",
      "Basic AI damage detection",
      "Standard parts & labor estimation",
      "Email support within 24h",
    ],
    highlight: false,
    ctaText: "Start Free Trial",
  },
  {
    id: "plan_professional",
    name: "Professional",
    desc: "For regional insurers and high-volume claim networks.",
    monthlyPrice: 14999,
    yearlyPrice: 11999,
    features: [
      "Up to 500 claim assessments/mo",
      "Full fraud detection suite (EXIF + duplicate detection)",
      "Explainable AI reports & PDF exports",
      "Interactive analytics & fraud queues",
      "Priority 4-hour email/chat support",
    ],
    highlight: true,
    ctaText: "Upgrade to Professional",
  },
  {
    id: "plan_enterprise",
    name: "Enterprise",
    desc: "For national insurers requiring custom deployment & SLAs.",
    monthlyPrice: "Custom",
    yearlyPrice: "Custom",
    features: [
      "Unlimited claim assessments",
      "Custom-tuned computer vision models",
      "Dedicated infrastructure (VPC/On-premises)",
      "SLA-backed 24/7 dedicated support",
      "Full REST API access & webhooks",
    ],
    highlight: false,
    ctaText: "Contact Enterprise Sales",
  },
];

const coreTechCapabilities = [
  {
    title: "Computer Vision Damper Analysis",
    desc: "Multi-angle image analysis locates and classifies scratches, dents, cracks, and structural damage in seconds with high precision.",
    label: "Core Technology",
  },
  {
    title: "Standardized Cost Matching",
    desc: "Direct integration with standardized repair indices automatically estimates localized parts replacement and labor hour demands.",
    label: "Valuation Engine",
  },
  {
    title: "EXIF & Duplicate Fraud Auditing",
    desc: "Analyzes image metadata timelines, geographical stamps, and pixel fingerprints to instantly flag double-submissions or anomalies.",
    label: "Fraud Shield",
  },
];

const partnerLinks = {
  Government: {
    title: "Government Portals",
    desc: "Official regulatory and transport ministries for policy verification and registration checks.",
    links: [
      { name: "Ministry of Road Transport & Highways (MoRTH)", url: "https://morth.nic.in/" },
      { name: "Parivahan Sewa Portal", url: "https://parivahan.gov.in/parivahansewa/" },
      { name: "Insurance Regulatory and Development Authority (IRDAI)", url: "https://irdai.gov.in/" },
    ],
  },
  Insurance: {
    title: "Insurance Company Networks",
    desc: "Instant claims integration and direct settlement partnerships with leading general insurance providers.",
    links: [
      { name: "ICICI Lombard General Insurance", url: "https://www.icicilombard.com/" },
      { name: "HDFC ERGO General Insurance", url: "https://www.hdfcergo.com/" },
      { name: "SBI General Insurance", url: "https://www.sbigeneral.in/" },
      { name: "Bajaj Allianz General Insurance", url: "https://www.bajajallianz.com/" },
      { name: "Reliance General Insurance", url: "https://www.reliancegeneral.co.in/" },
      { name: "Tata AIG General Insurance", url: "https://www.tataaig.com/" },
      { name: "New India Assurance", url: "https://www.newindia.co.in/" },
      { name: "Oriental Insurance Company", url: "https://www.orientalinsurance.org.in/" },
      { name: "United India Insurance", url: "https://uiic.co.in/" },
      { name: "National Insurance Company", url: "https://nationalinsurance.nic.in/" },
    ],
  },
  Automobile: {
    title: "Automobile Manufacturers",
    desc: "OEM parts pricing lookup, warranty verification, and data sync with leading manufacturers.",
    links: [
      { name: "Maruti Suzuki India", url: "https://www.marutisuzuki.com/" },
      { name: "Hyundai Motor India", url: "https://www.hyundai.com/in/en" },
      { name: "Tata Motors Passenger Vehicles", url: "https://www.tatamotors.com/" },
      { name: "Mahindra & Mahindra Auto", url: "https://auto.mahindra.com/" },
      { name: "Toyota Kirloskar Motor", url: "https://www.toyotabharat.com/" },
      { name: "Honda Cars India", url: "https://www.hondacarindia.com/" },
      { name: "Kia India", url: "https://www.kia.com/in/en" },
      { name: "MG Motor India", url: "https://www.mgmotor.co.in/" },
      { name: "Renault India", url: "https://www.renault.co.in/" },
      { name: "Nissan Motor India", url: "https://www.nissan.in/" },
      { name: "Volkswagen India", url: "https://www.volkswagen.co.in/en" },
      { name: "Skoda Auto India", url: "https://www.skoda-auto.co.in/" },
    ],
  },
  Dealership: {
    title: "Official Dealer Locators",
    desc: "Find official dealerships and authorized showroom networks across India.",
    links: [
      { name: "Maruti Suzuki Dealer Locator", url: "https://www.marutisuzuki.com/dealer-locator" },
      { name: "Hyundai Dealer Locator", url: "https://www.hyundai.com/in/en/find-a-dealer" },
      { name: "Tata Motors Dealer Locator", url: "https://dealer.tatamotors.com/" },
      { name: "Mahindra Dealer Locator", url: "https://auto.mahindra.com/dealer-locator" },
      { name: "Toyota Dealer Locator", url: "https://www.toyotabharat.com/find-a-dealer/" },
      { name: "Honda Cars Dealer Locator", url: "https://www.hondacarindia.com/honda-dealer-locator" },
      { name: "Kia Dealer Locator", url: "https://www.kia.com/in/en/find-dealer" },
      { name: "MG Motor Dealer Locator", url: "https://www.mgmotor.co.in/tools/dealer-locator" },
      { name: "Renault Dealer Locator", url: "https://www.renault.co.in/dealer-locator.html" },
      { name: "Nissan Dealer Locator", url: "https://www.nissan.in/tools/dealer-locator.html" },
      { name: "Volkswagen Dealer Locator", url: "https://www.volkswagen.co.in/en/find-a-dealer.html" },
      { name: "Skoda Dealer Locator", url: "https://www.skoda-auto.co.in/dealer-locator" },
    ],
  },
  "Repair Centers": {
    title: "Authorized Service Locators",
    desc: "Find certified repair facilities and authorized workshops for damage assessment audits.",
    links: [
      { name: "Maruti Suzuki Service Locator", url: "https://www.marutisuzuki.com/service-locator" },
      { name: "Hyundai Service Locator", url: "https://www.hyundai.com/in/en/find-a-dealer?type=service" },
      { name: "Tata Motors Service Locator", url: "https://dealer.tatamotors.com/" },
      { name: "Mahindra Service Locator", url: "https://auto.mahindra.com/dealer-locator" },
      { name: "Toyota Service Locator", url: "https://www.toyotabharat.com/find-a-dealer/" },
      { name: "Honda Service Locator", url: "https://www.hondacarindia.com/honda-service-locator" },
      { name: "Kia Service Locator", url: "https://www.kia.com/in/en/find-dealer?type=service" },
      { name: "MG Motor Service Locator", url: "https://www.mgmotor.co.in/tools/dealer-locator" },
      { name: "Renault Service Locator", url: "https://www.renault.co.in/renault-service/dealer-locator.html" },
      { name: "Nissan Service Locator", url: "https://www.nissan.in/tools/dealer-locator.html" },
      { name: "Volkswagen Service Locator", url: "https://www.volkswagen.co.in/en/find-a-dealer.html" },
      { name: "Skoda Service Locator", url: "https://www.skoda-auto.co.in/dealer-locator" },
    ],
  },
};

const faqs = [
  {
    q: "How accurate is the AI?",
    a: "The detection pipeline reports an average of 98% accuracy on labeled validation sets across common damage classes such as dents, scratches, cracks, and shattered components. Every prediction also carries its own confidence score so lower-certainty results can be routed to manual review instead of being silently accepted.",
  },
  {
    q: "How is repair cost estimated?",
    a: "Detected damage is matched against standardized parts and labor pricing tables by part, severity, and damage type. The system returns a cost range rather than a single number, reflecting the natural variance in repair estimates.",
  },
  {
    q: "How does fraud detection work?",
    a: "Three checks run in parallel: perceptual duplicate-image detection across the claim's photo set, EXIF metadata analysis for timestamp and location inconsistencies, and statistical anomaly detection comparing claimed cost against expected cost for the detected severity.",
  },
  {
    q: "Is my data secure?",
    a: "Uploaded images and claim data are encrypted in transit and at rest, and access is scoped by role — policyholders, repair partners, and claims officers each see only what they need.",
  },
];

export default function Home() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState(0);
  const { user, subscribe } = useClaims();
  const [isYearly, setIsYearly] = useState(false);
  const [activeCategory, setActiveCategory] = useState(null);
  const [activePlanCheckout, setActivePlanCheckout] = useState(null);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  function handleConfirmSubscription() {
    if (!agreedToTerms || !activePlanCheckout) return;
    setIsProcessing(true);
    setTimeout(() => {
      subscribe(activePlanCheckout.plan.name, activePlanCheckout.billing);
      setIsProcessing(false);
      setCheckoutSuccess(true);
    }, 1500);
  }

  return (
    <div>
      {/* HERO */}
      <section className="relative pt-40 pb-24 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
        <div className="absolute inset-0 grid-bg opacity-[0.15] pointer-events-none" />
        <div className="max-w-7xl mx-auto relative grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <FadeIn>
              <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-cyan-300 mb-6 px-3 py-1.5 rounded-full border border-cyan-400/20 bg-cyan-400/5">
                <Sparkles size={12} /> Computer Vision for Claims
              </span>
            </FadeIn>
            <FadeIn delay={0.05}>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.4rem] leading-[1.08] font-semibold tracking-tight text-frost">
                AI Powered Vehicle Damage Assessment{" "}
                <span className="text-gradient">&amp; Smart Insurance Claims</span>
              </h1>
            </FadeIn>
            <FadeIn delay={0.1}>
              <p className="mt-6 text-lg text-mist leading-relaxed max-w-xl">
                Upload damaged vehicle images and let AI instantly detect
                damages, estimate repair costs, identify fraud, and generate
                explainable insurance claim recommendations.
              </p>
            </FadeIn>
            <FadeIn delay={0.15}>
              <div className="mt-9 flex flex-wrap gap-4">
                <PrimaryButton onClick={() => navigate("/claim/new")}>
                  Start Claim <ArrowRight size={16} />
                </PrimaryButton>
                <GhostButton onClick={() => navigate("/dashboard")}>
                  <Play size={16} /> Watch Demo
                </GhostButton>
              </div>
            </FadeIn>

            <FadeIn delay={0.25}>
              <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6">
                {capabilities.map((c) => (
                  <div key={c.title} className="border-l border-cyan-400/20 pl-4 text-left">
                    <div className="font-display text-base font-semibold text-frost">
                      {c.title}
                    </div>
                    <div className="text-xs text-mist mt-1 leading-relaxed">{c.desc}</div>
                  </div>
                ))}
              </div>
            </FadeIn>
          </div>

          <FadeIn delay={0.2} y={40}>
            <ScanVisual />
          </FadeIn>
        </div>
      </section>

      {/* TRUSTED BY */}
      <section className="px-6 py-14 border-y border-line bg-panel/40">
        <div className="max-w-7xl mx-auto">
          <p className="text-center text-xs font-mono uppercase tracking-[0.2em] text-mist/60 mb-8">
            Built for every stakeholder in the claims lifecycle
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-8">
            {trustedBy.map(({ icon: Icon, label }) => (
              <button
                key={label}
                onClick={() => setActiveCategory(label)}
                className="flex flex-col items-center gap-2 text-mist/50 hover:text-cyan-300 transition-all transform hover:scale-105 duration-200 cursor-pointer bg-transparent border-none outline-none focus:outline-none"
              >
                <div className="w-12 h-12 rounded-xl bg-white/[0.02] border border-line flex items-center justify-center mb-1 hover:border-cyan-400/30">
                  <Icon size={24} strokeWidth={1.5} className="text-mist/70 hover:text-cyan-300" />
                </div>
                <span className="text-xs font-medium tracking-wide">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="px-6 py-28">
        <div className="max-w-7xl mx-auto">
          <FadeIn>
            <SectionEyebrow>Platform</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost max-w-2xl">
              Everything an insurer needs to resolve a claim without a site visit
            </h2>
          </FadeIn>
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <FadeIn key={f.title} delay={i * 0.05}>
                <GlassCard hover className="p-7 h-full">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-700/60 to-cyan-400/20 border border-cyan-400/20 flex items-center justify-center mb-5">
                    <f.icon size={20} className="text-cyan-300" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-frost mb-2">
                    {f.title}
                  </h3>
                  <p className="text-sm text-mist leading-relaxed">{f.desc}</p>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-7xl mx-auto">
          <FadeIn>
            <SectionEyebrow>Process</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost max-w-2xl">
              From upload to decision in seven explainable steps
            </h2>
          </FadeIn>

          <div className="mt-16 relative">
            <div className="hidden lg:block absolute top-0 bottom-0 left-[27px] w-px bg-gradient-to-b from-cyan-400/40 via-line to-transparent" />
            <div className="space-y-10">
              {steps.map((s, i) => (
                <FadeIn key={s.title} delay={i * 0.04}>
                  <div className="flex items-start gap-6">
                    <div className="relative shrink-0 w-14 h-14 rounded-2xl glass flex items-center justify-center">
                      <s.icon size={22} className="text-cyan-300" />
                      <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-blue-600 text-[10px] font-mono flex items-center justify-center text-frost border border-ink">
                        {i + 1}
                      </span>
                    </div>
                    <div className="pt-2">
                      <h4 className="font-display font-semibold text-frost text-base">
                        {s.title}
                      </h4>
                      <p className="text-sm text-mist mt-1">{s.desc}</p>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DEMO DASHBOARD PREVIEW */}
      <section className="px-6 py-28">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-14 items-center">
          <FadeIn>
            <SectionEyebrow>Live Preview</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-5">
              See exactly what the assessor sees
            </h2>
            <p className="text-mist leading-relaxed mb-8 max-w-lg">
              Every claim result includes the detected damage regions, an
              estimated repair cost, a confidence score, and a plain-English
              recommendation your team can act on immediately.
            </p>
            <GhostButton onClick={() => navigate("/claim/new")}>
              Try it yourself <ArrowRight size={16} />
            </GhostButton>
          </FadeIn>

          <FadeIn delay={0.1}>
            <GlassCard className="p-6">
              <div className="flex items-center justify-between mb-5">
                <span className="text-xs font-mono text-mist">CLAIM #CV-10245</span>
                <DecisionBadge decision="APPROVED" />
              </div>
              <div className="space-y-3 mb-5">
                <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-white/[0.02] border border-line">
                  <span className="text-sm text-frost">Front Bumper Dent</span>
                  <span className="text-sm font-mono text-cyan-300">92%</span>
                </div>
                <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-white/[0.02] border border-line">
                  <span className="text-sm text-frost">Headlight Broken</span>
                  <span className="text-sm font-mono text-cyan-300">89%</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Est. Cost</div>
                  <div className="font-mono text-frost text-sm">₹24,500</div>
                </div>
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Confidence</div>
                  <div className="font-mono text-frost text-sm">95%</div>
                </div>
                <div className="rounded-lg bg-white/[0.02] border border-line p-3 text-center">
                  <div className="text-[10px] text-mist uppercase tracking-wide mb-1">Fraud Risk</div>
                  <div className="font-mono text-ok text-sm">LOW</div>
                </div>
              </div>
            </GlassCard>
          </FadeIn>
        </div>
      </section>

      {/* CLAIM UPLOAD TEASER */}
      <section className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-4xl mx-auto text-center">
          <FadeIn>
            <SectionEyebrow>Start a Claim</SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-5">
              Ready when your images are
            </h2>
            <p className="text-mist mb-10 max-w-xl mx-auto">
              Drag and drop multiple angles of the vehicle, add the incident
              details, and receive a full assessment in seconds.
            </p>
          </FadeIn>
          <FadeIn delay={0.1}>
            <GlassCard
              className="p-14 border-dashed border-2 border-line hover:border-cyan-400/40 transition-colors cursor-pointer"
              onClick={() => navigate("/claim/new")}
            >
              <UploadCloud size={36} className="text-cyan-300 mx-auto mb-4" />
              <p className="text-frost font-medium">Click to start your claim upload</p>
              <p className="text-sm text-mist mt-1">JPG, PNG — up to 10 images</p>
            </GlassCard>
          </FadeIn>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="px-6 py-28">
        <div className="max-w-7xl mx-auto">
          <FadeIn className="text-center max-w-2xl mx-auto">
            <SectionEyebrow>
              <span className="mx-auto">Pricing</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Plans that scale with claim volume
            </h2>
          </FadeIn>

          {/* Billing Cycle Toggle */}
          <div className="mt-8 flex justify-center">
            <div className="bg-white/[0.03] border border-line rounded-xl p-1 flex items-center gap-1">
              <button
                onClick={() => setIsYearly(false)}
                className={`text-xs font-semibold px-4 py-2 rounded-lg transition-colors ${!isYearly ? "bg-gradient-to-r from-cyan-300 to-blue-500 text-ink" : "text-mist hover:text-frost"
                  }`}
              >
                Monthly Billing
              </button>
              <button
                onClick={() => setIsYearly(true)}
                className={`text-xs font-semibold px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${isYearly ? "bg-gradient-to-r from-cyan-300 to-blue-500 text-ink" : "text-mist hover:text-frost"
                  }`}
              >
                Yearly Billing
                <span className="bg-white/10 text-[9px] font-mono px-1.5 py-0.5 rounded-full">
                  Save 20%
                </span>
              </button>
            </div>
          </div>

          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {pricingPlans.map((plan, i) => {
              const hasPrice = typeof plan.monthlyPrice === "number";
              const displayPrice = hasPrice
                ? isYearly
                  ? `₹${plan.yearlyPrice.toLocaleString()}`
                  : `₹${plan.monthlyPrice.toLocaleString()}`
                : "Custom";
              const displayPeriod = hasPrice ? "/ month" : "";

              return (
                <FadeIn key={plan.name} delay={i * 0.06}>
                  <GlassCard
                    className={`p-8 h-full flex flex-col ${plan.highlight ? "border-cyan-400/40 shadow-glow relative" : ""
                      }`}
                  >
                    {plan.highlight && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[10px] font-mono uppercase tracking-wide bg-gradient-to-r from-cyan-300 to-blue-500 text-ink px-3 py-1 rounded-full font-semibold">
                        Most Popular
                      </span>
                    )}
                    <h3 className="font-display text-xl font-semibold text-frost">{plan.name}</h3>
                    <p className="text-sm text-mist mt-2 mb-6">{plan.desc}</p>
                    <div className="mb-6">
                      <span className="font-display text-3xl font-semibold text-frost">{displayPrice}</span>
                      <span className="text-mist text-sm">{displayPeriod}</span>
                      {hasPrice && isYearly && plan.yearlyPrice > 0 && (
                        <div className="text-[10px] text-mist mt-1 font-mono">
                          Billed annually (₹{(plan.yearlyPrice * 12).toLocaleString()}/yr)
                        </div>
                      )}
                    </div>
                    <ul className="space-y-3 mb-8 flex-1">
                      {plan.features.map((f) => (
                        <li key={f} className="flex items-start gap-2.5 text-sm text-mist">
                          <Check size={16} className="text-cyan-300 mt-0.5 shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => {
                        if (plan.id === "plan_enterprise") {
                          navigate("/contact?plan=enterprise");
                        } else if (user) {
                          setActivePlanCheckout({ plan, billing: isYearly ? "yearly" : "monthly" });
                        } else {
                          navigate(`/register?plan=${plan.name}&billing=${isYearly ? "yearly" : "monthly"}`);
                        }
                      }}
                      className={
                        plan.highlight
                          ? "w-full text-sm font-semibold text-ink bg-gradient-to-r from-cyan-300 to-blue-500 hover:opacity-90 rounded-xl px-6 py-3 transition-opacity"
                          : "w-full text-sm font-semibold text-frost border border-line hover:border-cyan-400/50 rounded-xl px-6 py-3 transition-colors"
                      }
                    >
                      {plan.ctaText}
                    </button>
                  </GlassCard>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* PLATFORM CAPABILITIES */}
      <section className="px-6 py-28 bg-panel/40 border-y border-line">
        <div className="max-w-7xl mx-auto">
          <FadeIn className="text-center max-w-2xl mx-auto">
            <SectionEyebrow>
              <span className="mx-auto">Capabilities</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Enterprise-grade motor claim automation
            </h2>
          </FadeIn>
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {coreTechCapabilities.map((c, i) => (
              <FadeIn key={c.title} delay={i * 0.06}>
                <GlassCard className="p-7 h-full flex flex-col">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-300 mb-3">{c.label}</span>
                  <h3 className="font-display font-semibold text-frost text-base mb-3">{c.title}</h3>
                  <p className="text-mist text-sm leading-relaxed flex-1">
                    {c.desc}
                  </p>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="px-6 py-28">
        <div className="max-w-3xl mx-auto">
          <FadeIn className="text-center mb-14">
            <SectionEyebrow>
              <span className="mx-auto">FAQ</span>
            </SectionEyebrow>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost">
              Frequently asked questions
            </h2>
          </FadeIn>
          <div className="space-y-3">
            {faqs.map((f, i) => (
              <FadeIn key={f.q} delay={i * 0.04}>
                <GlassCard className="overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? -1 : i)}
                    className="w-full flex items-center justify-between px-6 py-5 text-left"
                  >
                    <span className="font-medium text-frost">{f.q}</span>
                    <ChevronDown
                      size={18}
                      className={`text-cyan-300 transition-transform shrink-0 ml-4 ${openFaq === i ? "rotate-180" : ""
                        }`}
                    />
                  </button>
                  <motion.div
                    initial={false}
                    animate={{ height: openFaq === i ? "auto" : 0 }}
                    className="overflow-hidden"
                  >
                    <p className="px-6 pb-5 text-sm text-mist leading-relaxed">{f.a}</p>
                  </motion.div>
                </GlassCard>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="px-6 pb-28">
        <div className="max-w-5xl mx-auto">
          <FadeIn>
            <GlassCard className="p-14 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
              <div className="relative">
                <h2 className="font-display text-3xl sm:text-4xl font-semibold text-frost mb-4">
                  Ready to accelerate your claims process?
                </h2>
                <p className="text-mist mb-8 max-w-lg mx-auto">
                  Start your first claim assessment in under a minute — no
                  manual inspection required.
                </p>
                <PrimaryButton onClick={() => navigate("/claim/new")}>
                  Start Claim <ArrowRight size={16} />
                </PrimaryButton>
              </div>
            </GlassCard>
          </FadeIn>
        </div>
      </section>

      {/* PARTNER LINKS MODAL */}
      {activeCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/80 backdrop-blur-md">
          <GlassCard className="w-full max-w-2xl max-h-[80vh] overflow-y-auto p-8 border border-cyan-400/20 relative">
            <button
              onClick={() => setActiveCategory(null)}
              className="absolute top-4 right-4 text-mist hover:text-frost p-1 cursor-pointer bg-transparent border-none"
            >
              <X size={20} />
            </button>
            <h3 className="font-display text-2xl font-semibold text-frost mb-2">
              {partnerLinks[activeCategory].title}
            </h3>
            <p className="text-sm text-mist mb-6">
              {partnerLinks[activeCategory].desc}
            </p>
            <div className="space-y-3">
              {partnerLinks[activeCategory].links.map((link) => (
                <a
                  key={link.name}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 rounded-xl bg-white/[0.02] border border-line hover:border-cyan-400/30 transition-all flex items-center justify-between group"
                >
                  <div className="text-left">
                    <div className="text-sm font-semibold text-frost group-hover:text-cyan-300 transition-colors">
                      {link.name}
                    </div>
                    <div className="text-xs text-mist mt-1 truncate max-w-[280px] sm:max-w-md md:max-w-xl">
                      {link.url}
                    </div>
                  </div>
                  <ArrowRight size={16} className="text-mist group-hover:text-cyan-300 transition-transform group-hover:translate-x-1 shrink-0 ml-4" />
                </a>
              ))}
            </div>
          </GlassCard>
        </div>
      )}

      {/* PLAN CHECKOUT MODAL */}
      {activePlanCheckout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/80 backdrop-blur-md">
          <GlassCard className="w-full max-w-md p-8 border border-cyan-400/20 relative">
            <button
              onClick={() => {
                if (!isProcessing) {
                  setActivePlanCheckout(null);
                  setAgreedToTerms(false);
                  setCheckoutSuccess(false);
                }
              }}
              className="absolute top-4 right-4 text-mist hover:text-frost p-1 cursor-pointer bg-transparent border-none"
              disabled={isProcessing}
            >
              <X size={20} />
            </button>

            {checkoutSuccess ? (
              <div className="text-center py-6">
                <div className="w-12 h-12 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto mb-4 text-cyan-300">
                  <Check size={24} />
                </div>
                <h3 className="font-display text-xl font-semibold text-frost">Subscription Active!</h3>
                <p className="text-sm text-mist mt-2 mb-6">
                  You have successfully subscribed to the <strong>{activePlanCheckout.plan.name}</strong> ({activePlanCheckout.billing}) plan.
                </p>
                <PrimaryButton
                  onClick={() => {
                    setActivePlanCheckout(null);
                    setAgreedToTerms(false);
                    setCheckoutSuccess(false);
                    navigate("/dashboard");
                  }}
                  className="w-full justify-center"
                >
                  Go to Dashboard
                </PrimaryButton>
              </div>
            ) : (
              <div className="text-left">
                <h3 className="font-display text-xl font-semibold text-frost mb-1">
                  Subscribe to {activePlanCheckout.plan.name}
                </h3>
                <p className="text-xs text-mist mb-6">
                  Verify details before completing subscription.
                </p>

                <div className="rounded-xl bg-white/[0.02] border border-line p-4 mb-6 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-mist">Plan</span>
                    <span className="text-frost font-medium">{activePlanCheckout.plan.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-mist">Billing Cycle</span>
                    <span className="text-frost font-medium capitalize">{activePlanCheckout.billing}</span>
                  </div>
                  <div className="flex justify-between text-sm border-t border-line pt-3">
                    <span className="text-mist">Amount</span>
                    <span className="text-frost font-semibold">
                      {activePlanCheckout.billing === "yearly"
                        ? `₹${activePlanCheckout.plan.yearlyPrice.toLocaleString()}/mo`
                        : `₹${activePlanCheckout.plan.monthlyPrice.toLocaleString()}/mo`
                      }
                    </span>
                  </div>
                  <div className="text-[10px] text-mist text-right">
                    {activePlanCheckout.billing === "yearly" && (
                      <span>Billed annually (₹{(activePlanCheckout.plan.yearlyPrice * 12).toLocaleString()}/yr)</span>
                    )}
                  </div>
                </div>

                <div className="mb-6">
                  <label className="flex items-start gap-2.5 text-xs text-mist cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                      className="accent-cyan-400 mt-0.5 shrink-0"
                      disabled={isProcessing}
                    />
                    <span>
                      I explicitly agree to the Terms & Conditions and authorize the subscription billing for this account.
                    </span>
                  </label>
                </div>

                <PrimaryButton
                  onClick={handleConfirmSubscription}
                  disabled={!agreedToTerms || isProcessing}
                  className="w-full justify-center"
                >
                  {isProcessing ? "Processing Payment..." : "Confirm & Subscribe"}
                </PrimaryButton>
              </div>
            )}
          </GlassCard>
        </div>
      )}
    </div>
  );
}
