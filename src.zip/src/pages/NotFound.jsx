import { Link } from "react-router-dom";
import { ScanEye } from "lucide-react";
import { PrimaryButton, FadeIn } from "../components/ui";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6 text-center">
      <FadeIn>
        <ScanEye size={40} className="text-cyan-300 mx-auto mb-6" />
        <h1 className="font-display text-3xl font-semibold text-frost mb-3">Page not found</h1>
        <p className="text-mist mb-8">The page you're looking for doesn't exist.</p>
        <Link to="/">
          <PrimaryButton>Back to home</PrimaryButton>
        </Link>
      </FadeIn>
    </div>
  );
}
