import { useState } from "react";
import { User, Mail, Phone, Building2 } from "lucide-react";
import { GlassCard, SectionEyebrow, PrimaryButton, FadeIn } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";

export default function Profile() {
  const { user, claims, updateProfile } = useClaims();

  const [name, setName] = useState(user?.name || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [organization, setOrganization] = useState(user?.organization || "");
  const [saved, setSaved] = useState(false);

  function handleSave(e) {
    e.preventDefault();
    updateProfile({ name, phone, organization });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "U";

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-3xl mx-auto">
        <FadeIn className="mb-10">
          <SectionEyebrow>Account</SectionEyebrow>
          <h1 className="font-display text-3xl font-semibold text-frost">Profile</h1>
        </FadeIn>

        <FadeIn delay={0.05}>
          <GlassCard className="p-8 mb-6">
            <form onSubmit={handleSave}>
              <div className="flex items-center gap-5 mb-8">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-400 flex items-center justify-center font-display text-xl font-semibold text-ink shrink-0">
                  {initials}
                </div>
                <div>
                  <h2 className="font-display text-xl font-semibold text-frost">{user?.name}</h2>
                  <p className="text-sm text-mist">
                    {user?.organization || "Independent Assessor"} · {user?.plan || "Starter"} Plan
                  </p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="text-xs font-medium text-mist mb-2 block">Full name</label>
                  <div className="relative">
                    <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-mist mb-2 block">Email</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                    <input
                      type="email"
                      readOnly
                      disabled
                      value={user?.email || ""}
                      className="w-full bg-white/[0.01] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-mist/60 focus:outline-none cursor-not-allowed"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-mist mb-2 block">Phone</label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 XXXXX XXXXX"
                      className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-mist mb-2 block">Organization</label>
                  <div className="relative">
                    <Building2 size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                    <input
                      type="text"
                      value={organization}
                      onChange={(e) => setOrganization(e.target.value)}
                      placeholder="e.g. Northline Insurance"
                      className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost focus:outline-none focus:border-cyan-400/50"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between mt-6">
                <span className="text-xs text-cyan-300 font-mono">
                  {saved ? "Changes saved successfully!" : ""}
                </span>
                <PrimaryButton type="submit">Save changes</PrimaryButton>
              </div>
            </form>
          </GlassCard>
        </FadeIn>

        <FadeIn delay={0.1}>
          <GlassCard className="p-8">
            <h3 className="font-display font-semibold text-frost mb-4">Activity</h3>
            <p className="text-sm text-mist">
              You have filed <span className="text-frost font-medium">{claims.length}</span> claims total.
            </p>
          </GlassCard>
        </FadeIn>
      </div>
    </div>
  );
}
