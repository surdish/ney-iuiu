import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ScanEye, Mail, Lock, User, ArrowRight } from "lucide-react";
import { GlassCard, PrimaryButton, FadeIn } from "../components/ui";
import { useClaims } from "../lib/ClaimsContext";

export default function Register() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { register } = useClaims();

  const plan = searchParams.get("plan") || "Starter";
  const billing = searchParams.get("billing") || "monthly";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!agreed) {
      setError("You must explicitly agree to the Terms & Conditions before registering.");
      return;
    }
    setError(null);
    setLoading(true);

    try {
      await register(name, email, password, plan, billing);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-28 pb-16 relative">
      <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
      <FadeIn className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-400 shadow-glow">
              <ScanEye size={20} className="text-ink" strokeWidth={2.5} />
            </span>
          </Link>
          <h1 className="font-display text-2xl font-semibold text-frost">Create your account</h1>
          <p className="text-sm text-mist mt-2">Start assessing claims in minutes</p>
        </div>

        {plan && (
          <div className="mb-4 py-2.5 px-4 rounded-xl bg-cyan-400/5 border border-cyan-400/10 text-xs text-cyan-300 text-center font-medium">
            Registering with plan: <span className="font-semibold text-frost">{plan}</span> ({billing})
          </div>
        )}

        <GlassCard className="p-8">
          {error && (
            <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400 font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-xs font-medium text-mist mb-2 block">Full name</label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                <input
                  type="text"
                  required
                  placeholder="Jane Doe"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setError(null);
                  }}
                  className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-mist mb-2 block">Email address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                <input
                  type="email"
                  required
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                  className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-mist mb-2 block">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(null);
                  }}
                  className="w-full bg-white/[0.03] border border-line rounded-xl pl-11 pr-4 py-3 text-sm text-frost placeholder:text-mist/50 focus:outline-none focus:border-cyan-400/50 transition-colors"
                />
              </div>
            </div>
            <label className="flex items-start gap-2.5 text-xs text-mist cursor-pointer select-none">
              <input
                type="checkbox"
                required
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="accent-cyan-400 mt-0.5 shrink-0"
              />
              <span>
                I explicitly agree to the Terms & Conditions and Privacy Policy
              </span>
            </label>
            <PrimaryButton type="submit" className="w-full justify-center" disabled={loading}>
              {loading ? "Creating account..." : "Create account"} {!loading && <ArrowRight size={16} />}
            </PrimaryButton>
          </form>
        </GlassCard>

        <p className="text-center text-sm text-mist mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-cyan-300 hover:text-cyan-200 font-medium">
            Login
          </Link>
        </p>
      </FadeIn>
    </div>
  );
}
