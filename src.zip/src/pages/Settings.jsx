import { useState } from "react";
import { SectionEyebrow, GlassCard, FadeIn } from "../components/ui";

const initialToggles = [
  { key: "emailAlerts", label: "Email me when a claim is decided", desc: "Get notified the moment a claim reaches Approved, Manual Review, or Rejected.", on: true },
  { key: "fraudAlerts", label: "High-risk fraud alerts", desc: "Immediate alert when a claim crosses the high fraud-risk threshold.", on: true },
  { key: "weeklyDigest", label: "Weekly summary digest", desc: "A Monday morning summary of claim volume and outcomes.", on: false },
  { key: "autoApprove", label: "Auto-approve low-risk claims under ₹5,000", desc: "Skip manual review for small, high-confidence, low-risk claims.", on: false },
];

export default function Settings() {
  const [toggles, setToggles] = useState(initialToggles);

  function toggle(key) {
    setToggles((prev) => prev.map((t) => (t.key === key ? { ...t, on: !t.on } : t)));
  }

  return (
    <div className="min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-3xl mx-auto">
        <FadeIn className="mb-10">
          <SectionEyebrow>Preferences</SectionEyebrow>
          <h1 className="font-display text-3xl font-semibold text-frost">Settings</h1>
        </FadeIn>

        <FadeIn delay={0.05}>
          <GlassCard className="p-6 divide-y divide-line">
            {toggles.map((t) => (
              <div key={t.key} className="flex items-center justify-between py-5 first:pt-0 last:pb-0">
                <div className="pr-6">
                  <p className="text-sm font-medium text-frost">{t.label}</p>
                  <p className="text-xs text-mist mt-1">{t.desc}</p>
                </div>
                <button
                  onClick={() => toggle(t.key)}
                  className={`relative shrink-0 w-11 h-6 rounded-full transition-colors ${
                    t.on ? "bg-gradient-to-r from-cyan-300 to-blue-500" : "bg-line"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-5 h-5 rounded-full bg-frost transition-transform ${
                      t.on ? "translate-x-[22px]" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>
            ))}
          </GlassCard>
        </FadeIn>
      </div>
    </div>
  );
}
